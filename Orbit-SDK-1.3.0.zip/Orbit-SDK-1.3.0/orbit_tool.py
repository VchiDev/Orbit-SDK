#!/usr/bin/env python3
"""Orbit SDK 1.3.0: compiler, bytecode VM, package tools and library host."""
from __future__ import annotations
import argparse, ast, json, math, operator, os, re, shutil, sys, zipfile, tempfile, hashlib, hmac, secrets, csv, io, time, platform, subprocess
from pathlib import Path, PurePosixPath
from typing import Any
from orbit_stdlib import BUILTINS, LIBRARY_FUNCTIONS

VERSION = "1.3.0"
FORMAT = "ORBIT-BEAM-2"
ALPHABET = "01234567ABCDEFGH"
SDK = Path(__file__).resolve().parent
LIBS = SDK / "libraries"

class OrbitError(Exception): pass

# Orbit Memory Code: a compact two-character alphabet retained for legacy data.
def encode_number(number):
    if not 0 <= int(number) <= 255: raise ValueError("Memory character code must be between 0 and 255")
    n=int(number)
    if n==0: return "00"
    result=""
    while n: result=ALPHABET[n%16]+result; n//=16
    return result.rjust(2,"0")

def decode_number(value):
    if len(value)!=2 or any(c not in ALPHABET for c in value): raise ValueError("Invalid Orbit Memory Code character")
    return ALPHABET.index(value[0])*16+ALPHABET.index(value[1])

def encode_address(number):
    n=int(number)
    if not 0<=n<=65535: raise ValueError("Invalid memory address")
    return "".join(ALPHABET[(n>>shift)&15] for shift in (12,8,4,0))

def encode_text(value):
    result=[]
    for char in str(value):
        code=ord(char)-32
        if not 0<=code<=255: raise ValueError(f"Unsupported Orbit Memory Code character: {char!r}")
        result.append(encode_number(code))
    return "".join(result)

def decode_text(value):
    if len(value)%2: raise ValueError("Invalid encoded string length")
    return "".join(chr(decode_number(value[i:i+2])+32) for i in range(0,len(value),2))

class Token:
    __slots__ = ("kind", "value", "line", "col")
    def __init__(self, kind, value, line, col): self.kind, self.value, self.line, self.col = kind, value, line, col
    def __repr__(self): return f"{self.kind}:{self.value}"

TOKEN_RE = re.compile(r'''(?P<SPACE>[ \t\r]+)|(?P<NEWLINE>\n)|(?P<COMMENT>//[^\n]*|\#[^\n]*)|(?P<STRING>"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')|(?P<FLOAT>\d+\.\d+)|(?P<INT>\d+)|(?P<ID>[A-Za-z_][A-Za-z0-9_]*)|(?P<OP>==|!=|<=|>=|&&|\|\||\+=|-=|\*=|/=|->|[+*/%<>=!(){}\[\],;:.\-])''')

def lex(source: str):
    out=[]; pos=0; line=1; col=1
    while pos < len(source):
        m=TOKEN_RE.match(source,pos)
        if not m: raise OrbitError(f"Line {line}, column {col}: unexpected character {source[pos]!r}")
        kind,value=m.lastgroup,m.group(); start=(line,col); pos=m.end()
        if kind == "NEWLINE": out.append(Token("NL", value, *start)); line+=1; col=1; continue
        col += len(value)
        if kind in ("SPACE","COMMENT"): continue
        if kind == "ID" and value in ("true","false","null","and","or","not","in"): kind="KW"
        out.append(Token(kind,value,*start))
    out.append(Token("EOF","",line,col)); return out

class Parser:
    PRE={"or":1,"||":1,"and":2,"&&":2,"==":3,"!=":3,"in":3,"<":4,"<=":4,">":4,">=":4,"+":5,"-":5,"*":6,"/":6,"%":6}
    def __init__(self,source): self.tokens=lex(source); self.i=0
    def cur(self): return self.tokens[self.i]
    def eat(self,value=None,kind=None):
        t=self.cur()
        if value is not None and t.value!=value: raise OrbitError(f"Line {t.line}, column {t.col}: expected {value!r}, got {t.value!r}")
        if kind is not None and t.kind!=kind: raise OrbitError(f"Line {t.line}, column {t.col}: expected {kind}, got {t.value!r}")
        self.i+=1; return t
    def skip(self):
        while self.cur().kind=="NL" or self.cur().value==";": self.i+=1
    def parse(self):
        body=[]; self.skip()
        while self.cur().kind!="EOF": body.append(self.stmt()); self.skip()
        return body
    def block(self):
        self.eat("{"); self.skip(); body=[]
        while self.cur().value!="}":
            if self.cur().kind=="EOF": raise OrbitError("Unclosed block")
            body.append(self.stmt()); self.skip()
        self.eat("}"); return body
    def stmt(self):
        t=self.cur()
        if t.value in ("lux","orbit") and self.i+2<len(self.tokens) and self.tokens[self.i+1].value=="." and self.tokens[self.i+2].value=="loadLib":
            self.i+=3; self.eat("(")
            if self.cur().kind=="STRING": spec=ast.literal_eval(self.eat().value)
            else:
                parts=[self.eat(kind="ID").value]
                while self.cur().value==".": self.eat(); parts.append(self.eat(kind="ID").value)
                spec=".".join(parts)
            self.eat(")"); return ("loadlib",spec,t.line)
        if t.value in ("var","let","const"):
            kind=self.eat().value; name=self.eat(kind="ID").value; self.eat("="); return ("decl",kind,name,self.expr(),t.line)
        if t.value in ("fn","function"):
            self.eat(); name=self.eat(kind="ID").value; self.eat("("); params=[]
            if self.cur().value!=")":
                params.append(self.eat(kind="ID").value)
                while self.cur().value==",": self.eat(); params.append(self.eat(kind="ID").value)
            self.eat(")")
            if len(set(params))!=len(params): raise OrbitError(f"Line {t.line}: duplicate function parameter")
            return ("function",name,params,self.block(),t.line)
        if t.value=="if":
            self.eat(); cond=self.expr(); yes=self.block(); self.skip(); no=[]
            if self.cur().value=="else":
                self.eat()
                if self.cur().value=="if": no=[self.stmt()]
                else: no=self.block()
            return ("if",cond,yes,no,t.line)
        if t.value=="while": self.eat(); cond=self.expr(); return ("while",cond,self.block(),t.line)
        if t.value=="for":
            self.eat(); name=self.eat(kind="ID").value; self.eat("in"); iterable=self.expr(); return ("for",name,iterable,self.block(),t.line)
        if t.value=="return":
            self.eat(); return ("return",None if self.cur().kind in ("NL","EOF") or self.cur().value in (";","}") else self.expr(),t.line)
        if t.value in ("break", "continue"):
            self.eat(); return (t.value, t.line)
        if t.kind=="ID":
            target=self.expr()
            if self.cur().value in ("=","+=","-=","*=","/="):
                op=self.eat().value; value=self.expr()
                if target[0]=="var":
                    if op!="=": value=("bin",op[0],target,value)
                    return ("assign",target[1],value,t.line)
                if target[0]=="index": return ("setindex",target[1],target[2],op,value,t.line)
                if target[0]=="member": return ("setmember",target[1],target[2],op,value,t.line)
                raise OrbitError(f"Line {t.line}: assignment target must be a variable, list index, or object member")
            return ("expr",target,t.line)
        return ("expr",self.expr(),t.line)
    def expr(self,minp=0):
        t=self.cur()
        if t.value in ("!","-","+","not"):
            self.eat(); left=("un",t.value,self.expr(7))
        elif t.value=="(": self.eat(); left=self.expr(); self.eat(")")
        elif t.kind=="STRING": left=("lit",ast.literal_eval(self.eat().value))
        elif t.kind=="INT": left=("lit",int(self.eat().value))
        elif t.kind=="FLOAT": left=("lit",float(self.eat().value))
        elif t.value in ("true","false","null"):
            self.eat(); left=("lit",{"true":True,"false":False,"null":None}[t.value])
        elif t.kind=="ID": left=("var",self.eat().value)
        elif t.value=="[":
            self.eat(); items=[]
            if self.cur().value!="]":
                items.append(self.expr())
                while self.cur().value==",": self.eat(); items.append(self.expr())
            self.eat("]"); left=("list",items)
        elif t.value=="{":
            self.eat(); pairs=[]
            if self.cur().value!="}":
                while True:
                    keytok=self.cur()
                    if keytok.kind=="STRING": key=ast.literal_eval(self.eat().value)
                    elif keytok.kind=="ID": key=self.eat().value
                    else: raise OrbitError(f"Line {keytok.line}: object keys must be strings or identifiers")
                    self.eat(":"); pairs.append((key,self.expr()))
                    if self.cur().value!=",": break
                    self.eat(",")
            self.eat("}"); left=("map",pairs)
        else: raise OrbitError(f"Line {t.line}, column {t.col}: expected expression")
        while True:
            if self.cur().value==".":
                self.eat(); member=self.eat(kind="ID").value; left=("member",left,member); continue
            if self.cur().value=="[":
                self.eat(); index=self.expr(); self.eat("]"); left=("index",left,index); continue
            if self.cur().value=="(" and left[0] in ("var","member"):
                self.eat(); args=[]
                if self.cur().value!=")":
                    args.append(self.expr())
                    while self.cur().value==",": self.eat(); args.append(self.expr())
                self.eat(")"); left=("call",self.name_of(left),args); continue
            op=self.cur().value; prec=self.PRE.get(op,-1)
            if prec<minp: break
            self.eat(); right=self.expr(prec+1); left=("bin",op,left,right)
        return left
    def name_of(self,node):
        if node[0]=="var": return node[1]
        if node[0]=="member": return self.name_of(node[1])+"."+node[2]
        raise OrbitError("Only named functions can be called")

class Compiler:
    def __init__(self): self.code=[]; self.functions={}; self.loop_stack=[]
    def emit(self,op,arg=None,line=0): self.code.append({"op":op,"arg":arg,"line":line}); return len(self.code)-1
    def patch(self,index,target): self.code[index]["arg"]=target
    def expression(self,n,line=0):
        k=n[0]
        if k=="lit": self.emit("CONST",n[1],line)
        elif k=="var": self.emit("LOAD",n[1],line)
        elif k=="un": self.expression(n[2],line); self.emit("UNARY",n[1],line)
        elif k=="bin" and n[1] in ("and", "&&"):
            self.expression(n[2],line); self.emit("DUP",None,line)
            end=self.emit("JUMP_FALSE",None,line); self.emit("POP",None,line)
            self.expression(n[3],line); self.patch(end,len(self.code))
        elif k=="bin" and n[1] in ("or", "||"):
            self.expression(n[2],line); self.emit("DUP",None,line)
            rhs=self.emit("JUMP_FALSE",None,line); end=self.emit("JUMP",None,line)
            self.patch(rhs,len(self.code)); self.emit("POP",None,line)
            self.expression(n[3],line); self.patch(end,len(self.code))
        elif k=="bin": self.expression(n[2],line); self.expression(n[3],line); self.emit("BINARY",n[1],line)
        elif k=="call":
            if n[1] == "orbit.LoadNano":
                if n[2]: raise OrbitError(f"Line {line}: orbit.LoadNano() does not accept arguments")
                self.emit("LOAD_NANO", {"requested": True}, line)
            else:
                for a in n[2]: self.expression(a,line)
                self.emit("CALL",{"name":n[1],"argc":len(n[2])},line)
        elif k=="list":
            for x in n[1]: self.expression(x,line)
            self.emit("BUILD_LIST",len(n[1]),line)
        elif k=="index": self.expression(n[1],line); self.expression(n[2],line); self.emit("GET_ITEM",None,line)
        elif k=="member": self.expression(n[1],line); self.emit("GET_ATTR",n[2],line)
        elif k=="map":
            for key,value in n[1]: self.emit("CONST",key,line); self.expression(value,line)
            self.emit("BUILD_MAP",len(n[1]),line)
        else: raise OrbitError(f"Unsupported expression node {k}")
    def statements(self,body,code=None):
        target=self.code if code is None else code
        original=self.code; self.code=target
        for s in body:
            typ=s[0]; line=s[-1]
            if typ=="decl": self.expression(s[3],line); self.emit("DECLARE",{"name":s[2],"constant":s[1]=="const"},line)
            elif typ=="assign": self.expression(s[2],line); self.emit("STORE",s[1],line)
            elif typ=="setindex":
                self.expression(s[1],line); self.expression(s[2],line)
                if s[3]!="=": self.emit("DUP_PAIR",None,line); self.emit("GET_ITEM",None,line); self.expression(s[4],line); self.emit("BINARY",s[3][0],line)
                else: self.expression(s[4],line)
                self.emit("SET_ITEM",None,line)
            elif typ=="setmember":
                self.expression(s[1],line); self.emit("DUP",None,line); self.emit("GET_ATTR",s[2],line)
                if s[3]!="=": self.expression(s[4],line); self.emit("BINARY",s[3][0],line)
                else:
                    # For plain member assignment discard the old member value.
                    self.emit("POP",None,line); self.expression(s[4],line)
                self.emit("SET_ATTR",s[2],line)
            elif typ=="expr": self.expression(s[1],line); self.emit("POP",None,line)
            elif typ=="return":
                if s[1] is None: self.emit("CONST",None,line)
                else: self.expression(s[1],line)
                self.emit("RETURN",None,line)
            elif typ=="loadlib": self.emit("LOAD_LIB",s[1],line)
            elif typ=="if":
                self.expression(s[1],line); jf=self.emit("JUMP_FALSE",None,line); self.statements(s[2])
                if s[3]: j=self.emit("JUMP",None,line); self.patch(jf,len(self.code)); self.statements(s[3]); self.patch(j,len(self.code))
                else: self.patch(jf,len(self.code))
            elif typ=="while":
                start=len(self.code); self.expression(s[1],line); jf=self.emit("JUMP_FALSE",None,line)
                loop={"breaks":[],"continues":[],"continue_target":start}; self.loop_stack.append(loop)
                self.statements(s[2]); self.emit("JUMP",start,line); end=len(self.code); self.patch(jf,end)
                for jump in loop["breaks"]: self.patch(jump,end)
                for jump in loop["continues"]: self.patch(jump,start)
                self.loop_stack.pop()
            elif typ=="for":
                self.expression(s[2],line); self.emit("ITER_INIT",s[1],line); start=len(self.code); nxt=self.emit("ITER_NEXT",{"name":s[1],"target":None},line)
                loop={"breaks":[],"continues":[],"continue_target":start}; self.loop_stack.append(loop)
                self.statements(s[3]); self.emit("JUMP",start,line); end=len(self.code); self.patch(nxt,{"name":s[1],"target":end})
                for jump in loop["breaks"]: self.patch(jump,end)
                for jump in loop["continues"]: self.patch(jump,start)
                self.loop_stack.pop()
            elif typ in ("break", "continue"):
                if not self.loop_stack: raise OrbitError(f"Line {line}: {typ} can only be used inside a loop")
                jump=self.emit("JUMP",None,line); self.loop_stack[-1]["breaks" if typ=="break" else "continues"].append(jump)
            elif typ=="function":
                fname,params,body=s[1],s[2],s[3]
                if fname in self.functions: raise OrbitError(f"Line {line}: function {fname!r} already defined")
                fncode=[]; self.statements(body,fncode)
                if not fncode or fncode[-1]["op"]!="RETURN": fncode.append({"op":"CONST","arg":None,"line":line}); fncode.append({"op":"RETURN","arg":None,"line":line})
                self.functions[fname]={"params":params,"code":fncode}
        self.code=original
    def build(self,source):
        self.statements(Parser(source).parse()); self.emit("HALT")
        return {"format":FORMAT,"version":VERSION,"code":self.code,"functions":self.functions}

def compile_source(source): return Compiler().build(source)

_BINARY={"+":operator.add,"-":operator.sub,"*":operator.mul,"/":operator.truediv,"%":operator.mod,"==":operator.eq,"!=":operator.ne,"in":lambda a,b:operator.contains(b,a),"<":operator.lt,"<=":operator.le,">":operator.gt,">=":operator.ge,"and":lambda a,b:bool(a) and bool(b),"&&":lambda a,b:bool(a) and bool(b),"or":lambda a,b:bool(a) or bool(b),"||":lambda a,b:bool(a) or bool(b)}

def _run_program_inner(program,verbose=False,cwd=None,output=None,max_steps=5_000_000):
    if program.get("format")!=FORMAT: raise OrbitError("Unsupported BEAM format; recompile with this Orbit compiler")
    functions=program.get("functions",{}); stack=[]; loaded=set(); steps=0
    global_frame={"code":program["code"],"ip":0,"env":{},"const":set(),"parent":None,"base":0,"name":"<main>"}; frames=[global_frame]
    out=output if output is not None else print
    def find(frame,name):
        f=frame
        while f is not None:
            if name in f["env"]: return f
            f=f["parent"]
        return None
    while frames:
        frame=frames[-1]
        if frame["ip"]>=len(frame["code"]):
            frames.pop()
            if frames: del stack[frame["base"]:]; stack.append(None)
            continue
        ins=frame["code"][frame["ip"]]; frame["ip"]+=1; op,arg,line=ins["op"],ins.get("arg"),ins.get("line",0); steps+=1
        if steps>max_steps: raise OrbitError("Execution step limit exceeded (possible infinite loop)")
        if verbose: print(f"[{steps:05}] {frame['name']}:{frame['ip']-1:04} {op} {arg!r}",file=sys.stderr)
        try:
            if op=="CONST": stack.append(arg)
            elif op=="LOAD":
                f=find(frame,arg)
                if f is None: raise OrbitError(f"Line {line}: undefined variable {arg!r}")
                stack.append(f["env"][arg])
            elif op=="DECLARE":
                val=stack.pop(); name=arg["name"]
                if name in frame["env"]: raise OrbitError(f"Line {line}: {name!r} already declared in this scope")
                frame["env"][name]=val
                if arg["constant"]: frame["const"].add(name)
            elif op=="STORE":
                f=find(frame,arg)
                if f is None: raise OrbitError(f"Line {line}: undefined variable {arg!r}")
                if arg in f["const"]: raise OrbitError(f"Line {line}: cannot assign to constant {arg!r}")
                f["env"][arg]=stack.pop()
            elif op=="POP": stack.pop()
            elif op=="BUILD_LIST":
                n=arg; items=stack[-n:] if n else []
                if n: del stack[-n:]
                stack.append(items)
            elif op=="GET_ITEM":
                index=stack.pop(); obj=stack.pop(); stack.append(obj[index])
            elif op=="DUP": stack.append(stack[-1])
            elif op=="DUP_PAIR":
                index=stack.pop(); obj=stack.pop(); stack.extend([obj,index,obj,index])
            elif op=="SET_ITEM":
                value=stack.pop(); index=stack.pop(); obj=stack.pop(); obj[index]=value; stack.append(value)
            elif op=="GET_ATTR":
                obj=stack.pop(); stack.append(obj[arg] if isinstance(obj,dict) else getattr(obj,arg))
            elif op=="SET_ATTR":
                value=stack.pop(); obj=stack.pop()
                if isinstance(obj,dict): obj[arg]=value
                else: setattr(obj,arg,value)
                stack.append(value)
            elif op=="BUILD_MAP":
                n=arg; pairs=stack[-2*n:] if n else []
                if n: del stack[-2*n:]
                stack.append({pairs[i]:pairs[i+1] for i in range(0,len(pairs),2)})
            elif op=="ITER_INIT": frame["env"]["__iter_"+arg]=iter(stack.pop())
            elif op=="ITER_NEXT":
                try: frame["env"][arg["name"]]=next(frame["env"]["__iter_"+arg["name"]])
                except StopIteration: frame["ip"]=arg["target"]
            elif op=="LOAD_NANO":
                # Build-time directive; evaluates to null so expression statements remain balanced.
                stack.append(None)
            elif op=="LOAD_LIB":
                spec=arg
                if spec.startswith("orbit.") and not spec.endswith(".lux"): spec += ".lux"
                if spec.startswith("orbit."):
                    if not re.fullmatch(r"orbit\.[A-Za-z_][A-Za-z0-9_.]*\.lux",spec): raise OrbitError(f"Line {line}: invalid built-in Lux library reference {spec!r}")
                    path=LIBS/spec
                elif spec.startswith("lib/") and cwd is not None:
                    rel=PurePosixPath(spec)
                    if rel.is_absolute() or ".." in rel.parts or "\\" in spec: raise OrbitError(f"Line {line}: unsafe application Lux path")
                    path=(Path(cwd)/Path(*rel.parts)).resolve()
                    if not path.is_relative_to(Path(cwd).resolve()): raise OrbitError(f"Line {line}: application Lux path escapes project")
                else: raise OrbitError(f"Line {line}: invalid Lux library reference {spec!r}")
                metadata=lux_parse(path); loaded.add(metadata["NAME"])
                if metadata.get("SOURCE"):
                    if not metadata.get("NAMESPACE"):
                        raise OrbitError(f"Line {line}: custom Lux libraries with SOURCE must declare NAMESPACE")
                    source_rel=PurePosixPath(metadata["SOURCE"])
                    if source_rel.is_absolute() or ".." in source_rel.parts or "\\" in metadata["SOURCE"]:
                        raise OrbitError(f"Line {line}: unsafe custom library SOURCE path")
                    source_path=(path.parent/Path(*source_rel.parts)).resolve()
                    if not source_path.is_relative_to(path.parent.resolve()) or not source_path.is_file():
                        raise OrbitError(f"Line {line}: custom Lux source file is missing or outside lib/")
                    beam_path=source_path.with_suffix(".beam")
                    if beam_path.is_file():
                        module_program=json.loads(beam_path.read_text(encoding="utf-8"))
                        if module_program.get("format") != FORMAT:
                            raise OrbitError(f"Line {line}: custom library BEAM uses an incompatible format")
                    else:
                        # Direct `orbit run` remains convenient during development; packaged apps
                        # receive precompiled custom-library BEAM files from orbitpkg build.
                        module_program=compile_source(source_path.read_text(encoding="utf-8-sig"))
                    if module_program["code"] != [{"op":"HALT","arg":None,"line":0}]:
                        raise OrbitError(f"Line {line}: custom library source may contain function definitions only")
                    module_functions=module_program["functions"]
                    exports=metadata.get("EXPORT", []) or list(module_functions)
                    missing=[name for name in exports if name not in module_functions]
                    if missing: raise OrbitError(f"Line {line}: custom library exports undefined function(s): {', '.join(missing)}")
                    namespace=metadata["NAMESPACE"]
                    for local_name, fn_data in module_functions.items():
                        fn_copy={"params":list(fn_data["params"]),"code":[dict(ins) for ins in fn_data["code"]]}
                        for ins in fn_copy["code"]:
                            if ins.get("op")=="CALL" and ins.get("arg",{}).get("name") in module_functions:
                                ins["arg"]["name"]=namespace+"."+ins["arg"]["name"]
                        functions[namespace+"."+local_name]=fn_copy
                if verbose: print(f"Loaded Lux: {metadata['NAME']} {metadata['VERSION']}",file=sys.stderr)
            elif op=="UNARY":
                a=stack.pop(); stack.append((not bool(a)) if arg in ("!","not") else (-a if arg=="-" else +a))
            elif op=="BINARY":
                b=stack.pop(); a=stack.pop(); stack.append(_BINARY[arg](a,b))
            elif op=="CALL":
                argc=arg["argc"]; args=stack[-argc:] if argc else []
                if argc: del stack[-argc:]
                name=arg["name"]
                if name in functions:
                    fn=functions[name]; params=fn["params"]
                    if len(args)!=len(params): raise OrbitError(f"Line {line}: {name} expects {len(params)} arguments, got {len(args)}")
                    local=dict(zip(params,args)); frames.append({"code":fn["code"],"ip":0,"env":local,"const":set(),"parent":frame,"base":len(stack),"name":name})
                else:
                    if name in ("signal", "print"):
                        if len(args)!=1: raise OrbitError(f"Line {line}: {name} expects exactly one argument")
                        out(args[0]); stack.append(None); continue
                    fn=BUILTINS.get(name) or LIBRARY_FUNCTIONS.get(name)
                    if fn is None: raise OrbitError(f"Line {line}: unknown function {name!r}; load its Lux library and check the API name")
                    result=fn(*args)
                    if name=="console.read_line": result=str(result)
                    stack.append(result)
            elif op=="JUMP_FALSE":
                if not stack.pop(): frame["ip"]=arg
            elif op=="JUMP": frame["ip"]=arg
            elif op=="RETURN":
                result=stack.pop() if stack else None; frames.pop()
                if frames: del stack[frame["base"]:]; stack.append(result)
                else: return result
            elif op=="HALT": return None
            else: raise OrbitError(f"Unknown opcode {op}")
        except OrbitError: raise
        except Exception as exc: raise OrbitError(f"Line {line}: {type(exc).__name__}: {exc}") from exc
    return None

def run_program(program,verbose=False,cwd=None,output=None,max_steps=5_000_000):
    """Run bytecode with relative filesystem paths rooted at cwd, restoring host cwd afterward."""
    previous=os.getcwd()
    target=Path(cwd).resolve() if cwd is not None else None
    try:
        if target is not None: os.chdir(target)
        return _run_program_inner(program,verbose,cwd=target,output=output,max_steps=max_steps)
    finally:
        os.chdir(previous)

def write_beam(program,path): Path(path).write_text(json.dumps(program,indent=2,ensure_ascii=False)+"\n",encoding="utf-8")
def read_beam(path):
    data=json.loads(Path(path).read_text(encoding="utf-8"))
    if data.get("format")!=FORMAT: raise OrbitError("Invalid BEAM file or incompatible format")
    return data

def lux_parse(path):
    p=Path(path)
    if p.suffix!=".lux": raise OrbitError(f"{p.name}: Lux libraries must use the .lux extension")
    if not p.is_file(): raise OrbitError(f"Lux library not found: {p}")
    lines=[x.strip() for x in p.read_text(encoding="utf-8-sig").splitlines() if x.strip()]
    if not lines or lines[0]!="LUX-LIBRARY 01": raise OrbitError(f"{p.name}: invalid Lux header")
    d={"MODULE":[],"EXPORT":[]}
    for line in lines[1:]:
        k,_,v=line.partition(" ")
        if not v: raise OrbitError(f"{p.name}: malformed metadata")
        if k=="MODULE": d["MODULE"].append(v)
        elif k=="EXPORT": d["EXPORT"].append(v)
        elif k in ("NAME","VERSION","STATUS","DESCRIPTION","NAMESPACE","SOURCE"):
            if k in d: raise OrbitError(f"{p.name}: duplicate {k}")
            d[k]=v
        else: raise OrbitError(f"{p.name}: unknown field {k}")
    if not all(k in d for k in ("NAME","VERSION","STATUS")) or not d["MODULE"]: raise OrbitError(f"{p.name}: missing required metadata")
    if not re.fullmatch(r"\d+\.\d+\.\d+",d["VERSION"]): raise OrbitError(f"{p.name}: invalid semantic version")
    if "NAMESPACE" in d and not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*",d["NAMESPACE"]): raise OrbitError(f"{p.name}: invalid NAMESPACE")
    return d

def _program_requests_nano(program):
    code = list(program.get("code", []))
    for fn in program.get("functions", {}).values():
        code.extend(fn.get("code", []))
    return any(ins.get("op") == "LOAD_NANO" for ins in code)


def _write_embedded_nano(z, builtins, custom, manifest):
    """Embed the selected Nano runtime and its metadata into an .orbit archive."""
    files = _nano_runtime_files(builtins)
    z.writestr("nano/orbit_stdlib.py", (SDK / "orbit_stdlib.py").read_bytes())
    for rel in files:
        source = SDK / rel
        if not source.is_file():
            raise OrbitError(f"Cannot embed Nano: required runtime component is missing: {rel}")
        z.writestr("nano/" + rel, source.read_bytes())
    if "orbit.console" not in builtins:
        z.writestr("nano/libraries/orbit.console.lux", (LIBS / "orbit.console.lux").read_bytes())
    for name in builtins:
        lib = LIBS / (name + ".lux")
        if not lib.is_file():
            raise OrbitError(f"Cannot embed Nano: built-in Lux manifest not found: {name}")
        z.writestr("nano/libraries/" + lib.name, lib.read_bytes())
    # Include metadata for custom dependencies, while keeping custom implementations in /lib.
    metadata = {
        "runtime": "Orbit Nano", "runtime_version": VERSION,
        "format_version": 1, "application": manifest.get("name", "Orbit Application"),
        "embedded": True, "modules": builtins,
        "libraries": builtins, "custom_libraries": custom,
        "runtime_files": files, "assets_directory": "assets/",
        "custom_library_path": "lib/", "bytecode_format": FORMAT,
        "sdk_version": VERSION,
    }
    z.writestr("nano/metadata/nano.json", json.dumps(metadata, indent=2) + "\n")
    z.writestr("nano/metadata/dependencies.json", json.dumps({"built_in": builtins, "custom": custom}, indent=2) + "\n")
    z.writestr("nano/metadata/compatibility.json", json.dumps({"bytecode_format": FORMAT, "minimum_runtime_version": VERSION}, indent=2) + "\n")
    z.writestr("nano/metadata/build.json", json.dumps({"sdk_version": VERSION, "embedded_at_build": True}, indent=2) + "\n")
    runner = "from pathlib import Path\nimport json, sys\nROOT = Path(__file__).resolve().parent\nAPP_ROOT = ROOT.parent\nsys.path.insert(0, str(ROOT))\nfrom runtime.compact_vm import run_package, run_program\nif len(sys.argv) > 1 and Path(sys.argv[1]).suffix == '.orbit':\n    run_package(Path(sys.argv[1]))\nelse:\n    program = json.loads((APP_ROOT / 'main.beam').read_text(encoding='utf-8'))\n    run_program(program, cwd=APP_ROOT)\n"
    z.writestr("nano/run_embedded.py", runner)
    z.writestr("nano/run.ps1", '$ErrorActionPreference = "Stop"\npython (Join-Path $PSScriptRoot "run_embedded.py")\nif ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }\n')
    z.writestr("nano/run.bat", '@echo off\r\npython "%~dp0run_embedded.py"\r\n')
    z.writestr("nano/run.sh", '#!/usr/bin/env sh\ncd "$(dirname "$0")/.."\npython3 "$(dirname "$0")/run_embedded.py"\n')


def _program_library_dependencies(program):
    """Collect declared built-in and app-local Lux dependencies from all bytecode."""
    refs=[]
    code=list(program.get("code", []))
    for fn in program.get("functions", {}).values(): code.extend(fn.get("code", []))
    for ins in code:
        if ins.get("op") == "LOAD_LIB":
            spec=str(ins.get("arg", ""))
            if spec.startswith("orbit."):
                name=spec[:-4] if spec.endswith(".lux") else spec
                if name not in refs: refs.append(name)
            elif spec.startswith("lib/") and spec not in refs:
                refs.append(spec)
    return {"built_in": sorted(x for x in refs if x.startswith("orbit.")),
            "custom": sorted(x for x in refs if x.startswith("lib/"))}


# CLI -------------------------------------------------------------------------
def cli_compile(argv):
    p=argparse.ArgumentParser(prog="orbitc"); p.add_argument("source"); p.add_argument("-o","--output"); p.add_argument("--check",action="store_true"); p.add_argument("--version",action="version",version=f"Orbit Compiler {VERSION}"); a=p.parse_args(argv)
    src=Path(a.source)
    if not src.is_file() or src.suffix!=".orb": print("Expected an existing .orb source file",file=sys.stderr); return 2
    try:
        program=compile_source(src.read_text(encoding="utf-8-sig"))
        if a.check: print(f"OK: {src} ({len(program['code'])} instructions, {len(program['functions'])} functions)"); return 0
        out=Path(a.output) if a.output else src.with_suffix(".beam"); write_beam(program,out); print(f"Orbit {VERSION}: compiled {src} -> {out}"); return 0
    except Exception as exc: print(f"Orbit compiler error: {exc}",file=sys.stderr); return 1

def _program_root(path):
    resolved=Path(path).resolve()
    for parent in (resolved.parent,*resolved.parent.parents):
        if (parent/"orbit.json").is_file(): return parent
    return resolved.parent

def cli_vm(argv):
    p=argparse.ArgumentParser(prog="orbitvm"); p.add_argument("program"); p.add_argument("--verbose",action="store_true"); p.add_argument("--version",action="version",version=f"Orbit VM {VERSION}"); a=p.parse_args(argv)
    try: run_program(read_beam(a.program),a.verbose,_program_root(a.program)); return 0
    except Exception as exc: print(f"Orbit VM error: {exc}",file=sys.stderr); return 1

def _safe_archive_name(name):
    p=PurePosixPath(name)
    return not p.is_absolute() and ".." not in p.parts and "\\" not in name

def _read_package(package):
    with zipfile.ZipFile(package) as z:
        names=z.namelist()
        if any(not _safe_archive_name(n) for n in names): raise OrbitError("Package contains an unsafe path")
        if "orbit.json" not in names or "main.beam" not in names: raise OrbitError("Invalid .orbit package: missing orbit.json or main.beam")
        manifest=json.loads(z.read("orbit.json"))
        program=json.loads(z.read("main.beam"))
        if program.get("format")!=FORMAT: raise OrbitError("Package uses an incompatible BEAM format")
        return manifest,program,z

def _compile_custom_library_beams(project_root):
    """Compile app-local Lux source modules to adjacent BEAM files for distributable apps."""
    lib_root = (Path(project_root).resolve() / "lib")
    generated = {}
    if not lib_root.is_dir():
        return generated
    for lux_path in sorted(lib_root.rglob("*.lux")):
        metadata = lux_parse(lux_path)
        source_name = metadata.get("SOURCE")
        if not source_name:
            continue
        if not metadata.get("NAMESPACE"):
            raise OrbitError(f"{lux_path}: custom libraries with SOURCE must declare NAMESPACE")
        source_rel = PurePosixPath(source_name)
        if source_rel.is_absolute() or ".." in source_rel.parts or "\\" in source_name:
            raise OrbitError(f"{lux_path}: unsafe custom library SOURCE path")
        source_path = (lux_path.parent / Path(*source_rel.parts)).resolve()
        if not source_path.is_relative_to(lux_path.parent.resolve()) or not source_path.is_file():
            raise OrbitError(f"{lux_path}: custom library source is missing or escapes its lib directory")
        if source_path.suffix != ".orb":
            raise OrbitError(f"{lux_path}: custom Lux SOURCE files must use the .orb extension")
        program = compile_source(source_path.read_text(encoding="utf-8-sig"))
        if program["code"] != [{"op":"HALT","arg":None,"line":0}]:
            raise OrbitError(f"{lux_path}: custom library source may contain function definitions only")
        exports = metadata.get("EXPORT", []) or list(program["functions"])
        missing = [name for name in exports if name not in program["functions"]]
        if missing:
            raise OrbitError(f"{lux_path}: exports undefined function(s): {', '.join(missing)}")
        beam_path = source_path.with_suffix(".beam")
        rel = beam_path.relative_to(Path(project_root).resolve()).as_posix()
        generated[rel] = json.dumps(program, indent=2, ensure_ascii=False) + "\n"
    return generated


def cli_pkg(argv):
    p=argparse.ArgumentParser(prog="orbitpkg"); p.add_argument("--version",action="version",version=f"Orbit Package Manager {VERSION}"); sub=p.add_subparsers(dest="action",required=True)
    b=sub.add_parser("build"); b.add_argument("project",nargs="?",default="."); b.add_argument("-o","--output")
    r=sub.add_parser("run"); r.add_argument("package")
    i=sub.add_parser("inspect"); i.add_argument("package")
    a=p.parse_args(argv)
    try:
        if a.action=="build":
            root=Path(a.project).resolve(); manifest_path=root/"orbit.json"
            if not manifest_path.is_file(): raise OrbitError(f"Missing project manifest: {manifest_path}")
            from package_manager.manifest import validate_manifest
            manifest=validate_manifest(json.loads(manifest_path.read_text(encoding="utf-8")),root); entry=manifest.get("entry","src/main.orb")
            if not _safe_archive_name(entry): raise OrbitError("Unsafe entry path in orbit.json")
            src=(root/entry).resolve()
            if not src.is_relative_to(root) or not src.is_file(): raise OrbitError("Project entry file is missing or outside the project")
            program=compile_source(src.read_text(encoding="utf-8-sig")); out=Path(a.output).resolve() if a.output else root/(manifest.get("name","app")+".orbit")
            manifest["runtime_dependencies"]=_program_library_dependencies(program)
            custom_refs=manifest["runtime_dependencies"]["custom"]
            for ref in custom_refs:
                ref_path=PurePosixPath(ref)
                if ref_path.is_absolute() or ".." in ref_path.parts or not ref.startswith("lib/") or not (root/Path(*ref_path.parts)).is_file():
                    raise OrbitError(f"Referenced custom Lux library is missing or unsafe: {ref}")
            custom_beams=_compile_custom_library_beams(root)
            # Dependencies referenced inside custom Lux functions are part of the app too.
            built_in_dependencies=set(manifest["runtime_dependencies"]["built_in"])
            custom_dependencies=set(manifest["runtime_dependencies"]["custom"])
            for beam_text in custom_beams.values():
                module_program=json.loads(beam_text)
                module_deps=_program_library_dependencies(module_program)
                built_in_dependencies.update(module_deps["built_in"])
                custom_dependencies.update(module_deps["custom"])
            manifest["runtime_dependencies"]={"built_in":sorted(built_in_dependencies),"custom":sorted(custom_dependencies)}
            embed_nano = _program_requests_nano(program)
            manifest["embedded_nano"] = embed_nano
            for ref in manifest["runtime_dependencies"]["custom"]:
                ref_path=PurePosixPath(ref)
                if ref_path.is_absolute() or ".." in ref_path.parts or not ref.startswith("lib/") or not (root/Path(*ref_path.parts)).is_file():
                    raise OrbitError(f"Custom Lux dependency referenced from a library is missing or unsafe: {ref}")
            out.parent.mkdir(parents=True,exist_ok=True)
            with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
                z.writestr("orbit.json",json.dumps(manifest,indent=2)); z.writestr("main.beam",json.dumps(program,indent=2))
                for f in root.rglob("*"):
                    rel=f.relative_to(root).as_posix()
                    if f.is_file() and f.resolve()!=out and f.name!="orbit.json" and f.suffix!=".orbit" and rel not in custom_beams and not any(part in (".git","__pycache__") for part in f.relative_to(root).parts):
                        if f.suffix==".orb" and f.resolve()==src: continue
                        z.write(f,rel)
                for rel, beam_text in custom_beams.items():
                    z.writestr(rel,beam_text)
                # Keep a predictable assets/ root even when the project starts empty.
                if not any(name.startswith("assets/") for name in z.namelist()):
                    z.writestr("assets/", "")
                if embed_nano:
                    _write_embedded_nano(z, manifest["runtime_dependencies"]["built_in"], manifest["runtime_dependencies"]["custom"], manifest)
            print(f"Built {out}")
            if embed_nano: print("Embedded Orbit Nano and selected runtime dependencies")
            print("Packaged assets/: preserved")
            return 0
        with zipfile.ZipFile(a.package) as z:
            names=z.namelist()
            if any(not _safe_archive_name(n) for n in names): raise OrbitError("Package contains an unsafe path")
            if "orbit.json" not in names or "main.beam" not in names: raise OrbitError("Invalid .orbit package")
            manifest=json.loads(z.read("orbit.json"))
            if a.action=="inspect": print(json.dumps({"manifest":manifest,"files":names},indent=2)); return 0
            program=json.loads(z.read("main.beam"))
            with tempfile.TemporaryDirectory(prefix="orbit-app-") as tempdir:
                z.extractall(tempdir)
                if "nano/metadata/nano.json" in names:
                    runner = Path(tempdir) / "nano" / "run_embedded.py"
                    embedded_app = Path(tempdir) / Path(a.package).name
                    shutil.copy2(Path(a.package).resolve(), embedded_app)
                    result = subprocess.run([sys.executable, str(runner), str(embedded_app)], cwd=tempdir)
                    return result.returncode
                previous=os.getcwd()
                try:
                    os.chdir(tempdir)
                    run_program(program,cwd=Path(tempdir))
                finally: os.chdir(previous)
            return 0
    except Exception as exc: print(f"orbitpkg error: {exc}",file=sys.stderr); return 1

def _nano_runtime_files(builtin_libraries):
    """Return only the VM and runtime modules needed by the selected built-in Lux libraries."""
    modules = {"runtime/stdlib/console.py"}
    packages = {"runtime/__init__.py", "runtime/stdlib/__init__.py", "runtime/compact_vm.py"}
    engine_files, office_files = set(), set()
    mapping = {
        "orbit.console": ["console.py"], "orbit.math": ["mathlib.py"],
        "orbit.text": ["text.py"], "orbit.data": ["data.py"],
        "orbit.files": ["files.py"], "orbit.time": ["timelib.py"],
        "orbit.system": ["system.py"], "orbit.security": ["security.py"],
        "orbit.network": ["network.py"], "orbit.graphics": ["graphics.py"],
        "orbit.graphics3d": ["graphics3d.py", "graphics.py"], "orbit.physics": ["physics.py"],
        "orbit.animation": ["animation.py"], "orbit.audio": ["audio.py"],
        "orbit.window": ["window.py"], "orbit.ui": ["ui.py"],
        "orbit.input": ["input.py"], "orbit.debug": ["debug.py"],
        "orbit.database": ["database.py"],
        "orbit.desktop": ["window.py", "ui.py", "input.py"],
        "orbit.office": [],
        "orbit.fluxengine": ["graphics.py", "physics.py", "animation.py", "input.py"],
    }
    for library in builtin_libraries:
        if library not in mapping:
            raise OrbitError(f"Orbit Nano does not know how to bundle built-in library {library!r}")
        modules.update("runtime/stdlib/" + name for name in mapping[library])
        if library == "orbit.fluxengine":
            engine_files.update({"engine/__init__.py", "engine/flux/__init__.py", "engine/flux/core.py", "engine/flux/window.py"})
        if library == "orbit.office":
            office_files.update({"office/__init__.py", "office/core.py"})
    return sorted(packages | modules | engine_files | office_files)


def cli_nano(argv):
    parser = argparse.ArgumentParser(prog="orbitnano", description="Build a compact Orbit Nano VM runtime for an .orbit app")
    parser.add_argument("--version", action="version", version=f"Orbit Nano {VERSION}")
    sub = parser.add_subparsers(dest="action", required=True)
    build = sub.add_parser("build", help="bundle a game or app with only its required built-in runtime libraries")
    build.add_argument("package", help="input .orbit package")
    build.add_argument("-o", "--output", help="output Nano ZIP archive")
    args = parser.parse_args(argv)
    try:
        app_path = Path(args.package).resolve()
        if not app_path.is_file() or app_path.suffix != ".orbit":
            raise OrbitError("Orbit Nano expects an existing .orbit application package")
        with zipfile.ZipFile(app_path) as app_zip:
            names = app_zip.namelist()
            if any(not _safe_archive_name(n) for n in names):
                raise OrbitError("Application package contains an unsafe path")
            if "orbit.json" not in names or "main.beam" not in names:
                raise OrbitError("Invalid .orbit package")
            manifest = json.loads(app_zip.read("orbit.json"))
            program = json.loads(app_zip.read("main.beam"))
            if program.get("format") != FORMAT:
                raise OrbitError("Application was compiled with an incompatible Orbit VM format")
            dependencies = manifest.get("runtime_dependencies") or _program_library_dependencies(program)
            builtins = sorted(set(dependencies.get("built_in", [])))
            custom = sorted(set(dependencies.get("custom", [])))
            for library_path in custom:
                if library_path not in names:
                    raise OrbitError(f"Custom library {library_path!r} is referenced but missing from the .orbit package")
                # Ensure all custom source-backed Lux modules have their precompiled sibling BEAM.
                with app_zip.open(library_path) as stream:
                    lux_text = stream.read().decode("utf-8-sig")
                parsed = lux_parse_text(lux_text, library_path)
                source_name = parsed.get("SOURCE")
                if source_name:
                    source_rel = PurePosixPath(source_name)
                    if source_rel.is_absolute() or ".." in source_rel.parts or "\\" in source_name:
                        raise OrbitError(f"Custom library {library_path!r} has an unsafe SOURCE path")
                    base = PurePosixPath(library_path).parent
                    source_path = (base / source_rel).as_posix()
                    beam_path = str(PurePosixPath(source_path).with_suffix(".beam"))
                    if beam_path not in names:
                        raise OrbitError(f"Custom library {library_path!r} is missing compiled module {beam_path}; rebuild the app")
            files_to_copy = _nano_runtime_files(builtins)

        output = Path(args.output).resolve() if args.output else app_path.with_name(app_path.stem + "-OrbitNano.zip")
        output.parent.mkdir(parents=True, exist_ok=True)
        package_name = app_path.name
        list_builtin = ", ".join(builtins) if builtins else "(only the core console runtime)"
        nano_readme = (
            "# Orbit Nano runtime\n\n"
            f"This compact runtime bundle runs **{manifest.get('name', app_path.stem)}**.\n\n"
            f"- Built-in libraries embedded into Nano: {list_builtin}.\n"
            f"- Custom libraries remain inside `{package_name}` under its `lib/` directory.\n"
            "- Contains the BEAM VM and selected host modules, not the Orbit compiler or full SDK.\n"
            "- Python 3.10+ is required for this source-runtime distribution.\n\n"
            "Run `python run.py`, `run.ps1`, `run.bat`, or `./run.sh`.\n"
        )
        with zipfile.ZipFile(output, "w", zipfile.ZIP_DEFLATED) as nano_zip:
            prefix = "OrbitNano/"
            nano_zip.writestr(prefix + "README.md", nano_readme)
            nano_zip.writestr(prefix + "orbit_stdlib.py", (SDK / "orbit_stdlib.py").read_bytes())
            for rel in files_to_copy:
                source = SDK / rel
                if not source.is_file():
                    raise OrbitError(f"Required Nano runtime source is missing: {rel}")
                nano_zip.writestr(prefix + rel, source.read_bytes())
            # Only built-ins actually used by the app are embedded into Nano.
            nano_zip.writestr(prefix + "libraries/orbit.console.lux", (LIBS / "orbit.console.lux").read_bytes())
            for library in builtins:
                manifest_path = LIBS / (library + ".lux")
                if not manifest_path.is_file():
                    raise OrbitError(f"Built-in library manifest is missing: {library}")
                nano_zip.writestr(prefix + "libraries/" + manifest_path.name, manifest_path.read_bytes())
            nano_zip.writestr(prefix + "app/" + package_name, app_path.read_bytes())
            runner = (
                "from pathlib import Path\nimport sys\n"
                "ROOT = Path(__file__).resolve().parent\n"
                "sys.path.insert(0, str(ROOT))\n"
                "from runtime.compact_vm import run_package\n"
                "APP = next((ROOT / 'app').glob('*.orbit'))\n"
                "try:\n    run_package(APP)\n"
                "except Exception as exc:\n    print(f'Orbit Nano error: {exc}', file=sys.stderr)\n    raise SystemExit(1)\n"
            )
            nano_zip.writestr(prefix + "run.py", runner)
            nano_zip.writestr(prefix + "run.ps1", '$ErrorActionPreference = "Stop"\npython (Join-Path $PSScriptRoot "run.py")\nif ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }\n')
            nano_zip.writestr(prefix + "run.bat", '@echo off\r\npython "%~dp0run.py"\r\n')
            nano_zip.writestr(prefix + "run.sh", '#!/usr/bin/env sh\ncd "$(dirname "$0")"\npython3 run.py\n')
        print(f"Built Orbit Nano runtime: {output}")
        print(f"Built-in libraries embedded into Nano: {', '.join(builtins) if builtins else 'none'}")
        print(f"Custom libraries retained inside the .orbit app: {len(custom)}")
        print("Compiler included in Nano: no")
        return 0
    except Exception as exc:
        print(f"orbitnano error: {exc}", file=sys.stderr)
        return 1


def lux_parse_text(text, label="library.lux"):
    """Parse Lux metadata text copied from an app package."""
    lines=[line.strip() for line in text.splitlines() if line.strip()]
    if not lines or lines[0] != "LUX-LIBRARY 01": raise OrbitError(f"{label}: invalid Lux header")
    data={"MODULE":[],"EXPORT":[]}
    for line in lines[1:]:
        key,_,value=line.partition(" ")
        if not value: raise OrbitError(f"{label}: malformed metadata")
        if key in ("MODULE","EXPORT"): data[key].append(value)
        elif key in ("NAME","VERSION","STATUS","DESCRIPTION","NAMESPACE","SOURCE"):
            if key in data: raise OrbitError(f"{label}: duplicate {key}")
            data[key]=value
        else: raise OrbitError(f"{label}: unknown field {key}")
    if not all(key in data for key in ("NAME","VERSION","STATUS")) or not data["MODULE"]:
        raise OrbitError(f"{label}: missing required metadata")
    return data


def cli_lux(argv):
    p=argparse.ArgumentParser(prog="lux"); sub=p.add_subparsers(dest="action",required=True); sub.add_parser("list")
    q=sub.add_parser("inspect"); q.add_argument("name")
    q=sub.add_parser("validate"); q.add_argument("name")
    p.add_argument("--version",action="version",version=f"Orbit Lux {VERSION}"); a=p.parse_args(argv)
    try:
        if a.action=="list": paths=sorted(LIBS.glob("*.lux"))
        else:
            path=Path(a.name); paths=[path if path.is_file() else LIBS/(a.name if a.name.endswith(".lux") else a.name+".lux")]
        for path in paths:
            d=lux_parse(path)
            if a.action=="validate": print(f"VALID {d['NAME']} {d['VERSION']} — {len(d['MODULE'])} modules")
            else: print(f"{d['NAME']} {d['VERSION']} [{d['STATUS']}]"+(f" — {d.get('DESCRIPTION','')}" if a.action=="inspect" else ""))
            if a.action=="inspect": print("Modules: "+", ".join(d["MODULE"]))
        return 0
    except Exception as exc: print(f"Lux error: {exc}",file=sys.stderr); return 1

def cli_orbit(argv):
    p=argparse.ArgumentParser(prog="orbit"); p.add_argument("--version",action="version",version=f"Orbit SDK {VERSION}"); sub=p.add_subparsers(dest="command")
    sub.add_parser("version"); n=sub.add_parser("new"); n.add_argument("name"); n.add_argument("--template",choices=["console-app","game-prototype"],default="console-app")
    rr=sub.add_parser("run"); rr.add_argument("source")
    ff=sub.add_parser("fmt"); ff.add_argument("source"); ff.add_argument("--check",action="store_true")
    sub.add_parser("test")
    nn=sub.add_parser("nano"); nn_sub=nn.add_subparsers(dest="nano_action",required=True); nn_build=nn_sub.add_parser("build"); nn_build.add_argument("package"); nn_build.add_argument("-o","--output")
    mm=sub.add_parser("memory"); mm.add_argument("action",choices=["encode","decode","address"]); mm.add_argument("value")
    a,rest=p.parse_known_args(argv)
    if a.command is None: print(f"Orbit SDK {VERSION}\nCommands: new, run, compile, vm, package, nano, lux, fmt, test, memory, version"); return 0
    if a.command=="version": print(VERSION); return 0
    if a.command=="new":
        dest=Path(a.name); template=SDK/"templates"/a.template
        if dest.exists(): print(f"Destination already exists: {dest}",file=sys.stderr); return 2
        shutil.copytree(template,dest); print(f"Created {dest} from {a.template}"); return 0
    if a.command=="run":
        src=Path(a.source)
        if src.suffix == ".orbit":
            return cli_pkg(["run", str(src)])
        try: run_program(compile_source(src.read_text(encoding="utf-8-sig")),cwd=_program_root(src)); return 0
        except Exception as exc: print(f"Orbit run error: {exc}",file=sys.stderr); return 1
    if a.command=="fmt":
        from tools.formatter import format_file
        try:
            ok=format_file(a.source,check=a.check)
            if a.check and not ok: print(f"Needs formatting: {a.source}",file=sys.stderr); return 1
            print(f"Formatted: {a.source}" if not a.check else f"OK: {a.source}"); return 0
        except Exception as exc: print(f"Orbit formatter error: {exc}",file=sys.stderr); return 1
    if a.command=="test":
        return subprocess.call([sys.executable,"-m","unittest","discover","-s","tests","-v"],cwd=SDK)
    if a.command=="nano":
        args=["build", a.package]
        if a.output: args += ["--output", a.output]
        return cli_nano(args)
    if a.command=="memory":
        try:
            value=encode_text(a.value) if a.action=="encode" else decode_text(a.value) if a.action=="decode" else encode_address(int(a.value,0))
            print(value); return 0
        except Exception as exc: print(f"Orbit Memory Code error: {exc}",file=sys.stderr); return 1
    return {"compile":cli_compile,"vm":cli_vm,"package":cli_pkg,"lux":cli_lux,"nano":cli_nano}.get(a.command,lambda _:2)(rest)

def main():
    if len(sys.argv)<2: return cli_orbit([])
    cmd,args=sys.argv[1],sys.argv[2:]
    return {"compile":cli_compile,"vm":cli_vm,"package":cli_pkg,"lux":cli_lux,"orbitnano":cli_nano}.get(cmd,lambda _:cli_orbit(sys.argv[1:]))(args)

if __name__=="__main__": sys.exit(main())
