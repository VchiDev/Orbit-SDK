import re, unicodedata

def upper(s): return str(s).upper()
def lower(s): return str(s).lower()
def trim(s): return str(s).strip()
def split(s,sep=None): return str(s).split(sep)
def join(items,sep=""): return str(sep).join(str(x) for x in items)
def replace(s,old,new): return str(s).replace(str(old),str(new))
def contains(s,part): return str(part) in str(s)
def starts_with(s,prefix): return str(s).startswith(str(prefix))
def ends_with(s,suffix): return str(s).endswith(str(suffix))
def substring(s,start,end=None): return str(s)[int(start):None if end is None else int(end)]
def format(template,*args): return str(template).format(*args)
def normalize_unicode(s,form="NFC"): return unicodedata.normalize(form,str(s))
def matches(s,pattern): return bool(re.search(pattern,str(s)))
def regex_find_all(s,pattern): return re.findall(pattern,str(s))
def codepoints(s): return [ord(c) for c in str(s)]
def from_codepoints(items): return "".join(chr(int(x)) for x in items)
