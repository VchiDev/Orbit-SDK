import math

def lerp(a,b,t): return a+(b-a)*float(t)
def ease_in(t): return float(t)**2
def ease_out(t): return 1-(1-float(t))**2
def ease_in_out(t):
    t=max(0,min(1,float(t))); return 2*t*t if t<.5 else 1-((-2*t+2)**2)/2
def keyframe(time,value): return {"time":float(time),"value":value}
def timeline(keys,time,easing="linear"):
    keys=sorted(keys,key=lambda x:float(x["time"]))
    if not keys: raise ValueError("Timeline requires at least one keyframe")
    t=float(time)
    if t<=keys[0]["time"]: return keys[0]["value"]
    if t>=keys[-1]["time"]: return keys[-1]["value"]
    fn={"linear":lambda x:x,"ease_in":ease_in,"ease_out":ease_out,"ease_in_out":ease_in_out}.get(easing)
    if fn is None: raise ValueError("Unknown easing curve")
    for a,b in zip(keys,keys[1:]):
        if a["time"]<=t<=b["time"]:
            q=(t-a["time"])/(b["time"]-a["time"]); q=fn(q)
            if isinstance(a["value"],(int,float)) and isinstance(b["value"],(int,float)): return lerp(a["value"],b["value"],q)
            return b["value"] if q>=1 else a["value"]
def ping_pong(t,duration):
    d=float(duration)
    if d<=0: raise ValueError("Duration must be positive")
    x=(float(t)%(2*d)); return x if x<=d else 2*d-x
