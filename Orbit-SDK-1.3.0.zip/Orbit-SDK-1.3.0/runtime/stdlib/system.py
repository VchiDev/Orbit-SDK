import os, platform, sys

def os_name(): return platform.system().lower()
def os_version(): return platform.version()
def architecture(): return platform.machine()
def python_version(): return platform.python_version()
def cwd(): return os.getcwd()
def env(name,default=None): return os.environ.get(str(name),default)
def set_env(name,value): os.environ[str(name)]=str(value); return True
def args(): return list(sys.argv[1:])
def home(): return str(__import__('pathlib').Path.home())
def newline(): return os.linesep
