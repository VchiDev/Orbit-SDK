"""SQLite database API. SQL is parameterized by callers; connections are process-local."""
import sqlite3

def open_database(path=":memory:"):
    db=sqlite3.connect(str(path)); db.row_factory=sqlite3.Row; return db
def execute(db,sql,params=None):
    cur=db.execute(str(sql),tuple(params or [])); db.commit(); return {"rowcount":cur.rowcount,"lastrowid":cur.lastrowid}
def query(db,sql,params=None):
    cur=db.execute(str(sql),tuple(params or [])); return [dict(row) for row in cur.fetchall()]
def close(db): db.close(); return True
def table_exists(db,name):
    row=db.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",(str(name),)).fetchone(); return row is not None
