"""Simple deterministic 2D rigid-body helpers (units are application-defined)."""
import math

def body(x=0,y=0,vx=0,vy=0,mass=1,radius=1):
    if float(mass)<=0: raise ValueError("Body mass must be positive")
    return {"x":float(x),"y":float(y),"vx":float(vx),"vy":float(vy),"mass":float(mass),"radius":float(radius),"fx":0.0,"fy":0.0}
def apply_force(b,fx,fy): b["fx"]+=float(fx); b["fy"]+=float(fy); return b
def integrate(b,dt,gravity_x=0,gravity_y=0,damping=0):
    dt=float(dt); inv=1/b["mass"]; b["vx"]+=(b["fx"]*inv+float(gravity_x))*dt; b["vy"]+=(b["fy"]*inv+float(gravity_y))*dt
    damp=max(0.0,1-float(damping)*dt); b["vx"]*=damp; b["vy"]*=damp; b["x"]+=b["vx"]*dt; b["y"]+=b["vy"]*dt; b["fx"]=b["fy"]=0.0; return b
def circle_overlap(a,b):
    dx=a["x"]-b["x"]; dy=a["y"]-b["y"]; r=a["radius"]+b["radius"]; return dx*dx+dy*dy<=r*r
def aabb_overlap(a,b): return not (a["x"]+a["w"]<b["x"] or b["x"]+b["w"]<a["x"] or a["y"]+a["h"]<b["y"] or b["y"]+b["h"]<a["y"])
def distance(a,b): return math.hypot(a["x"]-b["x"],a["y"]-b["y"])
def bounce(b,normal_x,normal_y,restitution=1):
    nx,ny=float(normal_x),float(normal_y); mag=math.hypot(nx,ny)
    if not mag: return b
    nx/=mag; ny/=mag; dot=b["vx"]*nx+b["vy"]*ny
    if dot<0: b["vx"]-=(1+float(restitution))*dot*nx; b["vy"]-=(1+float(restitution))*dot*ny
    return b
def step(bodies,dt,gravity_y=9.81): return [integrate(b,dt,0,gravity_y) for b in bodies]

def resolve_aabb(a,b,restitution=0.0):
    """Resolve an overlapping AABB pair along its shallowest axis."""
    if not aabb_overlap(a,b): return False
    overlaps=[(min(a["x"]+a["w"],b["x"]+b["w"])-max(a["x"],b["x"]),"x"),
              (min(a["y"]+a["h"],b["y"]+b["h"])-max(a["y"],b["y"]),"y")]
    penetration,axis=min(overlaps,key=lambda item:item[0])
    if penetration<=0: return False
    ac=a[axis]+a["w" if axis=="x" else "h"]/2
    bc=b[axis]+b["w" if axis=="x" else "h"]/2
    sign=-1 if ac<bc else 1
    a[axis]+=sign*penetration/2; b[axis]-=sign*penetration/2
    av=a.get("v"+axis,0.0); bv=b.get("v"+axis,0.0)
    relative=av-bv
    if relative*sign<0:
        impulse=(1+max(0.0,float(restitution)))*relative/2
        a["v"+axis]-=impulse; b["v"+axis]+=impulse
    return True

def resolve_circle(a,b,restitution=0.0):
    """Resolve two circle bodies using a simple mass-weighted normal impulse."""
    dx=b["x"]-a["x"]; dy=b["y"]-a["y"]
    dist=math.hypot(dx,dy); minimum=a["radius"]+b["radius"]
    if dist>=minimum: return False
    if dist==0: dx,dy,dist=1.0,0.0,1.0
    nx,ny=dx/dist,dy/dist
    inv_a=1.0/a["mass"]; inv_b=1.0/b["mass"]; inv_sum=inv_a+inv_b
    correction=(minimum-dist)/inv_sum
    a["x"]-=nx*correction*inv_a; a["y"]-=ny*correction*inv_a
    b["x"]+=nx*correction*inv_b; b["y"]+=ny*correction*inv_b
    rvx=b["vx"]-a["vx"]; rvy=b["vy"]-a["vy"]
    along=rvx*nx+rvy*ny
    if along<0:
        impulse=-(1+max(0.0,float(restitution)))*along/inv_sum
        a["vx"]-=impulse*inv_a*nx; a["vy"]-=impulse*inv_a*ny
        b["vx"]+=impulse*inv_b*nx; b["vy"]+=impulse*inv_b*ny
    return True
