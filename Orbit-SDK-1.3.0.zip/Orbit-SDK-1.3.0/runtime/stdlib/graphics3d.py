"""Small deterministic CPU 3D renderer with wireframe and flat-shaded triangles."""
import math
from . import graphics

def mesh(vertices, edges=None, faces=None):
    verts = [tuple(float(n) for n in p[:3]) for p in vertices]
    edge_list = [tuple(map(int, e)) for e in (edges or [])]
    face_list = [tuple(map(int, f)) for f in (faces or [])]
    for group, label in ((edge_list, "edge"), (face_list, "face")):
        for item in group:
            if len(item) < (2 if label == "edge" else 3) or any(i < 0 or i >= len(verts) for i in item):
                raise ValueError(f"Invalid mesh {label}: {item}")
    return {"vertices": verts, "edges": edge_list, "faces": face_list}

def cube(size=1.0):
    s=float(size)/2
    v=[(-s,-s,-s),(s,-s,-s),(s,s,-s),(-s,s,-s),(-s,-s,s),(s,-s,s),(s,s,s),(-s,s,s)]
    e=[(0,1),(1,2),(2,3),(3,0),(4,5),(5,6),(6,7),(7,4),(0,4),(1,5),(2,6),(3,7)]
    f=[(0,1,2,3),(4,7,6,5),(0,4,5,1),(1,5,6,2),(2,6,7,3),(4,0,3,7)]
    return {"vertices":v,"edges":e,"faces":f}

def transform(model, rotation=None, position=None, scale=None):
    rx,ry,rz=map(float,rotation or [0,0,0]); px,py,pz=map(float,position or [0,0,0])
    if scale is None: sx=sy=sz=1.0
    elif isinstance(scale,(int,float)): sx=sy=sz=float(scale)
    else: sx,sy,sz=map(float,scale)
    out=[]
    for x,y,z in model["vertices"]:
        x,y,z=x*sx,y*sy,z*sz
        y,z=y*math.cos(rx)-z*math.sin(rx),y*math.sin(rx)+z*math.cos(rx)
        x,z=x*math.cos(ry)+z*math.sin(ry),-x*math.sin(ry)+z*math.cos(ry)
        x,y=x*math.cos(rz)-y*math.sin(rz),x*math.sin(rz)+y*math.cos(rz)
        out.append((x+px,y+py,z+pz))
    return {"vertices":out,"edges":list(model.get("edges",[])),"faces":list(model.get("faces",[]))}

def project_point(point,width,height,camera_z=5.0,scale=80.0):
    x,y,z=point; d=float(camera_z)-float(z)
    if d <= 0.1: return None
    factor=float(scale)/d
    return [float(width)/2+x*factor,float(height)/2-y*factor]

def _shade(color, intensity):
    base=graphics._color(color)
    k=max(0.18,min(1.0,float(intensity)))
    return tuple(int(base[i]*k) for i in range(3))+(base[3],)

def render_solid(canvas, model, color="#78bfff", camera_z=5.0, scale=100.0, light_dir=(-0.4,0.6,-1.0)):
    """Painter-sorted flat-shaded polygons. Intended for small indie scenes, not heavy meshes."""
    vertices=model["vertices"]; faces=model.get("faces",[])
    lx,ly,lz=map(float,light_dir); lm=math.sqrt(lx*lx+ly*ly+lz*lz) or 1.0
    light=(lx/lm,ly/lm,lz/lm)
    rendered=[]
    for face in faces:
        points=[vertices[i] for i in face]
        if any(float(camera_z)-p[2] <= 0.1 for p in points):
            continue
        a,b,c=points[0],points[1],points[2]
        u=(b[0]-a[0],b[1]-a[1],b[2]-a[2]); v=(c[0]-a[0],c[1]-a[1],c[2]-a[2])
        normal=(u[1]*v[2]-u[2]*v[1],u[2]*v[0]-u[0]*v[2],u[0]*v[1]-u[1]*v[0])
        nm=math.sqrt(sum(n*n for n in normal)) or 1.0
        ndotl=abs(sum((normal[i]/nm)*light[i] for i in range(3)))
        intensity=0.28+0.72*ndotl
        projected=[project_point(p,canvas["width"],canvas["height"],camera_z,scale) for p in points]
        depth=sum(p[2] for p in points)/len(points)
        rendered.append((depth,projected,_shade(color,intensity)))
    for _,points,shade in sorted(rendered,key=lambda item:item[0]):
        graphics.polygon(canvas,points,shade,True)
    return canvas

def render_wireframe(canvas,model,color="#ffffff",camera_z=5.0,scale=80.0):
    projected=[project_point(p,canvas["width"],canvas["height"],camera_z,scale) for p in model["vertices"]]
    for a,b in model.get("edges",[]):
        if projected[a] is not None and projected[b] is not None:
            graphics.line(canvas,*projected[a],*projected[b],color)
    return canvas
