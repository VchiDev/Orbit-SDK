import math as m

def vec2(x=0.0,y=0.0): return {"x":float(x),"y":float(y)}
def vec3(x=0.0,y=0.0,z=0.0): return {"x":float(x),"y":float(y),"z":float(z)}
def dot(a,b): return sum(float(a[k])*float(b[k]) for k in a if k in b)
def length(v): return m.sqrt(sum(float(x)**2 for x in v.values()))
def normalize(v):
    n=length(v)
    return {k:(x/n if n else 0.0) for k,x in v.items()}
def distance(a,b): return m.sqrt(sum((float(a[k])-float(b[k]))**2 for k in a if k in b))
def lerp(a,b,t): return a+(b-a)*t
def clamp(x,lo,hi): return max(lo,min(hi,x))
def map_range(x,a,b,c,d):
    if a==b: raise ValueError("Cannot map a zero-width input range")
    return c+(x-a)*(d-c)/(b-a)
def radians(x): return m.radians(x)
def degrees(x): return m.degrees(x)
def random():
    import random as r
    return r.random()
def random_int(a,b):
    import random as r
    return r.randint(int(a),int(b))


def pi(): return m.pi
def tau(): return m.tau
def e(): return m.e
def hypot(x,y): return m.hypot(float(x),float(y))
def is_finite(value): return m.isfinite(float(value))
