"""Synchronous HTTP/HTTPS client with bounded response sizes."""
from urllib.request import Request, urlopen
from urllib.parse import urlparse
from pathlib import Path

MAX_RESPONSE_BYTES = 2 * 1024 * 1024
MAX_DOWNLOAD_BYTES = 25 * 1024 * 1024

def _validate_url(url):
    parsed=urlparse(str(url))
    if parsed.scheme not in ("http","https") or not parsed.hostname:
        raise ValueError("Only absolute HTTP and HTTPS URLs are supported")
    return str(url)

def _request(url,data=None,headers=None,method=None,timeout=10):
    url=_validate_url(url)
    body=None if data is None else (data if isinstance(data,bytes) else str(data).encode())
    req=Request(url,data=body,headers=headers or {},method=method)
    with urlopen(req,timeout=float(timeout)) as response:
        raw=response.read(MAX_RESPONSE_BYTES+1)
        if len(raw)>MAX_RESPONSE_BYTES: raise ValueError("Network response exceeded 2 MiB safety limit")
        return {"status":response.status,"headers":dict(response.headers.items()),"body":raw.decode(response.headers.get_content_charset() or "utf-8",errors="replace"),"url":response.geturl()}

def get(url,timeout=10): return _request(url,timeout=timeout)
def post(url,body,content_type="application/json",timeout=10): return _request(url,body,{"Content-Type":content_type},"POST",timeout)
def head(url,timeout=10):
    r=_request(url,headers={},method="HEAD",timeout=timeout)
    return {"status":r["status"],"headers":r["headers"],"url":r["url"]}
def download(url,path,timeout=20):
    url=_validate_url(url); req=Request(url,method="GET")
    with urlopen(req,timeout=float(timeout)) as response:
        raw=response.read(MAX_DOWNLOAD_BYTES+1)
        if len(raw)>MAX_DOWNLOAD_BYTES: raise ValueError("Download exceeded 25 MiB safety limit")
        p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(raw)
        return {"path":str(p),"status":response.status,"bytes":len(raw)}
