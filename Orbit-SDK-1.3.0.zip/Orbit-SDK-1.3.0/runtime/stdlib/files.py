from pathlib import Path
import shutil, hashlib

def _p(path): return Path(str(path)).expanduser()
def exists(path): return _p(path).exists()
def is_file(path): return _p(path).is_file()
def is_dir(path): return _p(path).is_dir()
def read_text(path,encoding="utf-8"): return _p(path).read_text(encoding=encoding)
def write_text(path,text,encoding="utf-8"):
    p=_p(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(str(text),encoding=encoding); return str(p)
def read_bytes(path): return list(_p(path).read_bytes())
def write_bytes(path,data):
    p=_p(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(bytes(data)); return str(p)
def append_text(path,text,encoding="utf-8"):
    p=_p(path); p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("a",encoding=encoding) as f: f.write(str(text))
    return str(p)
def mkdir(path): _p(path).mkdir(parents=True,exist_ok=True); return str(_p(path))
def list_dir(path="."): return sorted(x.name for x in _p(path).iterdir())
def copy(source,destination):
    p=_p(destination); p.parent.mkdir(parents=True,exist_ok=True)
    return str(shutil.copy2(_p(source),p))
def move(source,destination):
    p=_p(destination); p.parent.mkdir(parents=True,exist_ok=True); return str(shutil.move(str(_p(source)),str(p)))
def remove(path):
    p=_p(path)
    if p.is_dir(): shutil.rmtree(p)
    elif p.exists(): p.unlink()
    return True
def join(*parts): return str(Path(*map(str,parts)))
def name(path): return _p(path).name
def extension(path): return _p(path).suffix
def sha256(path): return hashlib.sha256(_p(path).read_bytes()).hexdigest()
