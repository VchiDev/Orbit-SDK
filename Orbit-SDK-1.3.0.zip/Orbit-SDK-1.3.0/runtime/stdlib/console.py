import sys

def write(value=""):
    print(value, end=""); return None

def log(value=""):
    print(value); return None

def read_line(prompt=""):
    return input(str(prompt))

def clear():
    print("\033[2J\033[H", end=""); return None

def color(value, code="36"):
    return f"\033[{code}m{value}\033[0m"
