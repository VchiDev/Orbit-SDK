"""Input abstraction for headless and Tk hosts. Query values are false until a host binds them."""
_STATE={"keys":set(),"mouse_x":0,"mouse_y":0,"mouse_buttons":set()}
def key_down(name):
    key=str(name).lower()
    aliases={"esc":"escape","return":"enter","spacebar":"space"}
    return aliases.get(key,key) in _STATE["keys"]
def mouse_position(): return {"x":_STATE["mouse_x"],"y":_STATE["mouse_y"]}
def mouse_down(button=1): return int(button) in _STATE["mouse_buttons"]
def bind_tk(window):
    root=window["root"]
    root.bind("<KeyPress>",lambda e:_STATE["keys"].add(e.keysym.lower()))
    root.bind("<KeyRelease>",lambda e:_STATE["keys"].discard(e.keysym.lower()))
    root.bind("<Motion>",lambda e:_STATE.update(mouse_x=e.x,mouse_y=e.y))
    root.bind("<ButtonPress>",lambda e:_STATE["mouse_buttons"].add(e.num))
    root.bind("<ButtonRelease>",lambda e:_STATE["mouse_buttons"].discard(e.num))
    return True
