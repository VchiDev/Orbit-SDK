import json, csv, io, base64

def json_parse(value): return json.loads(value)
def json_stringify(value,pretty=False): return json.dumps(value,ensure_ascii=False,indent=2 if pretty else None,separators=None if pretty else (",",":"),default=str)
def csv_parse(value): return list(csv.DictReader(io.StringIO(value)))
def csv_stringify(rows):
    if not rows: return ""
    buf=io.StringIO(); writer=csv.DictWriter(buf,fieldnames=list(rows[0].keys())); writer.writeheader(); writer.writerows(rows); return buf.getvalue()
def base64_encode(value): return base64.b64encode(str(value).encode()).decode()
def base64_decode(value): return base64.b64decode(value).decode()
def keys(value): return list(value.keys()) if isinstance(value,dict) else list(range(len(value)))
def values(value): return list(value.values()) if isinstance(value,dict) else list(value)
def has(value,key): return key in value
def merge(a,b): return {**a,**b}
def sort(items): return sorted(items)
def unique(items): return list(dict.fromkeys(items))
def push(items,value): items.append(value); return items
def pop(items): return items.pop()
def contains(items,value): return value in items
