"""Tk widget helpers; widget calls return the underlying Tk object."""
def button(window,text,callback=None,x=10,y=10,width=None):
    import tkinter as tk
    widget=tk.Button(window["root"],text=str(text),command=callback)
    widget.place(x=int(x),y=int(y),width=None if width is None else int(width)); return widget
def entry(window,x=10,y=10,width=200):
    import tkinter as tk
    widget=tk.Entry(window["root"],width=max(1,int(width)//8)); widget.place(x=int(x),y=int(y)); return widget
def text_get(widget): return widget.get()
def text_set(widget,value):
    widget.delete(0,"end"); widget.insert(0,str(value)); return True
def checkbox(window,text,checked=False,x=10,y=10):
    import tkinter as tk
    v=tk.BooleanVar(value=bool(checked)); w=tk.Checkbutton(window["root"],text=str(text),variable=v); w.place(x=int(x),y=int(y)); return {"widget":w,"value":v}
def checked(control): return bool(control["value"].get())
