"""Optional Tk-based native desktop windows. Requires a working desktop session."""
def create(title="Orbit",width=800,height=600):
    try: import tkinter as tk
    except Exception as exc: raise RuntimeError(f"Tkinter is not available: {exc}")
    root=tk.Tk(); root.title(str(title)); root.geometry(f"{int(width)}x{int(height)}")
    return {"root":root,"title":str(title),"width":int(width),"height":int(height)}
def label(window,text,x=10,y=10):
    import tkinter as tk
    widget=tk.Label(window["root"],text=str(text)); widget.place(x=int(x),y=int(y)); return widget
def run(window): window["root"].mainloop(); return True
def close(window): window["root"].destroy(); return True
def set_title(window,title): window["root"].title(str(title)); return True
def set_size(window,width,height): window["root"].geometry(f"{int(width)}x{int(height)}"); return True
