import hashlib, hmac, secrets, base64

def sha256(value): return hashlib.sha256(str(value).encode()).hexdigest()
def sha512(value): return hashlib.sha512(str(value).encode()).hexdigest()
def hmac_sha256(key,message): return hmac.new(str(key).encode(),str(message).encode(),hashlib.sha256).hexdigest()
def secure_token(length=32): return secrets.token_urlsafe(int(length))
def random_bytes(length=32): return list(secrets.token_bytes(int(length)))
def constant_time_equal(a,b): return hmac.compare_digest(str(a),str(b))
def base64_encode(value): return base64.b64encode(str(value).encode()).decode()
def base64_decode(value): return base64.b64decode(value).decode()
