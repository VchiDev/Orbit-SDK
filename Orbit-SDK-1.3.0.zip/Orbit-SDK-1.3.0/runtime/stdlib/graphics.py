"""Dependency-free RGBA software canvas with PNG export."""
import struct, zlib, math

def _color(c):
    if isinstance(c,(list,tuple)): vals=list(c)
    else:
        s=str(c).lower(); named={"black":"#000000","white":"#ffffff","red":"#ff0000","green":"#00aa00","blue":"#0000ff","yellow":"#ffff00","cyan":"#00ffff","magenta":"#ff00ff","transparent":"#00000000","orange":"#ff8800"}
        s=named.get(s,s)
        if not s.startswith("#"): raise ValueError(f"Unsupported color {c!r}; use #RRGGBB or [r,g,b,a]")
        h=s[1:]
        if len(h)==6: vals=[int(h[i:i+2],16) for i in (0,2,4)]+[255]
        elif len(h)==8: vals=[int(h[i:i+2],16) for i in (0,2,4,6)]
        else: raise ValueError("Color hex must be #RRGGBB or #RRGGBBAA")
    if len(vals)==3: vals.append(255)
    if len(vals)!=4: raise ValueError("Color tuple must have 3 or 4 channels")
    return tuple(max(0,min(255,int(v))) for v in vals)

def canvas(width,height,background="#00000000"):
    w,h=int(width),int(height)
    if not (1<=w<=4096 and 1<=h<=4096): raise ValueError("Canvas dimensions must be between 1 and 4096")
    c={"width":w,"height":h,"pixels":bytearray(w*h*4)}
    col=_color(background)
    if col[3]:
        for i in range(0,len(c["pixels"]),4): c["pixels"][i:i+4]=bytes(col)
    return c

def pixel(c,x,y,color):
    x,y=int(x),int(y)
    if 0<=x<c["width"] and 0<=y<c["height"]:
        i=(y*c["width"]+x)*4; col=_color(color); c["pixels"][i:i+4]=bytes(col)
    return c

def clear(c,color="#00000000"):
    col=bytes(_color(color)); px=c["pixels"]
    for i in range(0,len(px),4): px[i:i+4]=col
    return c

def rect(c,x,y,w,h,color,filled=True,thickness=1):
    x,y,w,h=int(x),int(y),int(w),int(h)
    if w<0 or h<0: raise ValueError("Rectangle width and height must be non-negative")
    if filled:
        xa=max(0,x); xb=min(c["width"],x+w); ya=max(0,y); yb=min(c["height"],y+h); col=bytes(_color(color))
        for yy in range(ya,yb):
            start=(yy*c["width"]+xa)*4; end=(yy*c["width"]+xb)*4; c["pixels"][start:end]=col*max(0,xb-xa)
    else:
        for t in range(max(1,int(thickness))):
            line(c,x+t,y+t,x+w-1-t,y+t,color); line(c,x+t,y+h-1-t,x+w-1-t,y+h-1-t,color)
            line(c,x+t,y+t,x+t,y+h-1-t,color); line(c,x+w-1-t,y+t,x+w-1-t,y+h-1-t,color)
    return c

def line(c,x0,y0,x1,y1,color,thickness=1):
    x0,y0,x1,y1=map(int,(x0,y0,x1,y1)); dx=abs(x1-x0); sx=1 if x0<x1 else -1; dy=-abs(y1-y0); sy=1 if y0<y1 else -1; err=dx+dy
    while True:
        r=max(0,int(thickness)//2)
        for yy in range(y0-r,y0+r+1):
            for xx in range(x0-r,x0+r+1): pixel(c,xx,yy,color)
        if x0==x1 and y0==y1: break
        e2=2*err
        if e2>=dy: err+=dy; x0+=sx
        if e2<=dx: err+=dx; y0+=sy
    return c

def circle(c,cx,cy,radius,color,filled=True,thickness=1):
    cx,cy,r=int(cx),int(cy),int(radius)
    if r<0: raise ValueError("Circle radius must be non-negative")
    outer=r*r; inner=max(0,r-max(1,int(thickness)))**2
    for y in range(max(0,cy-r),min(c["height"],cy+r+1)):
        for x in range(max(0,cx-r),min(c["width"],cx+r+1)):
            d=(x-cx)**2+(y-cy)**2
            if (filled and d<=outer) or (not filled and inner<=d<=outer): pixel(c,x,y,color)
    return c

def polygon(c,points,color,filled=True):
    pts=[(int(p[0]),int(p[1])) for p in points]
    if len(pts)<3: raise ValueError("A polygon needs at least three points")
    if not filled:
        for i,p in enumerate(pts): line(c,*p,*pts[(i+1)%len(pts)],color)
        return c
    ymin=max(0,min(y for x,y in pts)); ymax=min(c["height"]-1,max(y for x,y in pts))
    for y in range(ymin,ymax+1):
        xs=[]
        for i,(x1,y1) in enumerate(pts):
            x2,y2=pts[(i+1)%len(pts)]
            if y1==y2: continue
            if min(y1,y2)<=y<max(y1,y2): xs.append(int(x1+(y-y1)*(x2-x1)/(y2-y1)))
        xs.sort()
        for a,b in zip(xs[::2],xs[1::2]):
            for x in range(max(0,a),min(c["width"],b+1)): pixel(c,x,y,color)
    return c

def text(c,x,y,value,color="#ffffff",scale=1):
    # A compact 5x7 bitmap font for ASCII letters/digits. Unsupported glyphs render as a box.
    import textwrap
    font = {
        "A": [14,17,17,31,17,17,17], "B": [30,17,17,30,17,17,30],
        "C": [14,17,16,16,16,17,14], "D": [30,17,17,17,17,17,30],
        "E": [31,16,16,30,16,16,31], "F": [31,16,16,30,16,16,16],
        "G": [14,17,16,23,17,17,15], "H": [17,17,17,31,17,17,17],
        "I": [14,4,4,4,4,4,14], "J": [7,2,2,2,18,18,12],
        "K": [17,18,20,24,20,18,17], "L": [16,16,16,16,16,16,31],
        "M": [17,27,21,21,17,17,17], "N": [17,25,21,19,17,17,17],
        "O": [14,17,17,17,17,17,14], "P": [30,17,17,30,16,16,16],
        "Q": [14,17,17,17,21,18,13], "R": [30,17,17,30,20,18,17],
        "S": [15,16,16,14,1,1,30], "T": [31,4,4,4,4,4,4],
        "U": [17,17,17,17,17,17,14], "V": [17,17,17,17,17,10,4],
        "W": [17,17,17,21,21,21,10], "X": [17,17,10,4,10,17,17],
        "Y": [17,17,10,4,4,4,4], "Z": [31,1,2,4,8,16,31],
        "0": [14,17,19,21,25,17,14], "1": [4,12,4,4,4,4,14],
        "2": [14,17,1,2,4,8,31], "3": [30,1,1,14,1,1,30],
        "4": [2,6,10,18,31,2,2], "5": [31,16,16,30,1,1,30],
        "6": [14,16,16,30,17,17,14], "7": [31,1,2,4,8,8,8],
        "8": [14,17,17,14,17,17,14], "9": [14,17,17,15,1,1,14],
        " ": [0]*7, ".": [0,0,0,0,0,12,12], "!": [4,4,4,4,4,0,4],
        ":": [0,12,12,0,12,12,0], "-": [0,0,0,31,0,0,0],
    }
    x,y,scale=int(x),int(y),max(1,int(scale)); cursor=x
    for ch in str(value).upper():
        rows=font.get(ch,[31,17,21,21,21,17,31])
        for ry,bits in enumerate(rows):
            for rx in range(5):
                if bits & (1<<(4-rx)):
                    for sy in range(scale):
                        for sx in range(scale): pixel(c,cursor+rx*scale+sx,y+ry*scale+sy,color)
        cursor+=6*scale
    return c

def _chunk(tag,data): return struct.pack(">I",len(data))+tag+data+struct.pack(">I",zlib.crc32(tag+data)&0xffffffff)
def save_png(c,path):
    from pathlib import Path
    w,h=c["width"],c["height"]; raw=b"".join(b"\0"+bytes(c["pixels"][y*w*4:(y+1)*w*4]) for y in range(h))
    png=b"\x89PNG\r\n\x1a\n"+_chunk(b"IHDR",struct.pack(">2I5B",w,h,8,6,0,0,0))+_chunk(b"IDAT",zlib.compress(raw,9))+_chunk(b"IEND",b"")
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(png); return str(p)
def pixel_get(c,x,y):
    x,y=int(x),int(y)
    if not (0<=x<c["width"] and 0<=y<c["height"]): return None
    i=(y*c["width"]+x)*4; return list(c["pixels"][i:i+4])
