"""WAV synthesis and optional host playback; no third-party packages."""
import math, wave, struct, subprocess, platform
from pathlib import Path

def tone(path,frequency=440,duration=1.0,volume=.25,sample_rate=44100,waveform="sine"):
    rate=int(sample_rate); frames=max(1,int(float(duration)*rate)); freq=float(frequency); amp=max(0,min(1,float(volume)))
    if not 8000<=rate<=192000: raise ValueError("Sample rate must be 8000..192000")
    if not 1<=freq<=rate/2: raise ValueError("Frequency must be between 1 Hz and Nyquist frequency")
    buf=bytearray()
    for i in range(frames):
        phase=2*math.pi*freq*i/rate
        if waveform=="sine": v=math.sin(phase)
        elif waveform=="square": v=1.0 if math.sin(phase)>=0 else -1.0
        elif waveform=="saw": v=2*((freq*i/rate)%1)-1
        elif waveform=="triangle": v=2*abs(2*((freq*i/rate)%1)-1)-1
        else: raise ValueError("Waveform must be sine, square, saw, or triangle")
        # 5ms fade-in/out to avoid sharp clicks.
        fade=min(1,i/(rate*.005),(frames-i-1)/(rate*.005)); sample=int(max(-1,min(1,v*amp*max(0,fade)))*32767)
        buf.extend(struct.pack("<h",sample))
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    with wave.open(str(p),"wb") as w: w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate); w.writeframes(buf)
    return {"path":str(p),"samples":frames,"duration":frames/rate,"sample_rate":rate}
def info(path):
    with wave.open(str(path),"rb") as w: return {"channels":w.getnchannels(),"sample_rate":w.getframerate(),"frames":w.getnframes(),"duration":w.getnframes()/w.getframerate(),"sample_width":w.getsampwidth()}
def play(path):
    p=Path(path)
    if not p.is_file(): raise FileNotFoundError(p)
    sys=platform.system()
    if sys=="Windows":
        import winsound; winsound.PlaySound(str(p),winsound.SND_FILENAME|winsound.SND_ASYNC); return True
    command=["afplay",str(p)] if sys=="Darwin" else ["aplay","-q",str(p)]
    try: subprocess.Popen(command,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL); return True
    except FileNotFoundError: raise RuntimeError("No supported audio playback command found; WAV export still works")
