import time, datetime

def now(): return datetime.datetime.now().astimezone().isoformat(timespec="seconds")
def unix(): return time.time()
def sleep(seconds): time.sleep(max(0,float(seconds))); return None
def timestamp(): return int(time.time())
def date_string(): return datetime.date.today().isoformat()
def measure_start(): return time.perf_counter()
def elapsed(start): return time.perf_counter()-float(start)
def format_timestamp(value,fmt="%Y-%m-%d %H:%M:%S"): return datetime.datetime.fromtimestamp(float(value)).strftime(fmt)
