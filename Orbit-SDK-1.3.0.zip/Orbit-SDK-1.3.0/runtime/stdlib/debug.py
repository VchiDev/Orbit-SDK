import pprint, time

def assert_true(condition,message="Assertion failed"):
    if not condition: raise AssertionError(str(message))
    return True
def type_of(value):
    if value is None: return "null"
    if isinstance(value,bool): return "boolean"
    if isinstance(value,int): return "integer"
    if isinstance(value,float): return "float"
    if isinstance(value,str): return "string"
    if isinstance(value,list): return "list"
    if isinstance(value,dict): return "object"
    return type(value).__name__
def inspect(value): return pprint.pformat(value,sort_dicts=True)
def profile_start(): return time.perf_counter()
def profile_end(start): return time.perf_counter()-float(start)
def breakpoint_message(message="Breakpoint"): print(f"[ORBIT DEBUG] {message}"); return True
