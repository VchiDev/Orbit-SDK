"""Function registry introspection."""
from orbit_stdlib import BUILTINS, LIBRARY_FUNCTIONS

def builtins(): return sorted(BUILTINS)
def library_functions(namespace=None):
    names=sorted(LIBRARY_FUNCTIONS)
    return [x for x in names if namespace is None or x.startswith(str(namespace)+".")]
