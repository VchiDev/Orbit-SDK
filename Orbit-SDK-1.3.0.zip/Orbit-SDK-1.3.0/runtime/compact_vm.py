"""Orbit Nano's compact BEAM-only runtime. This module deliberately has no compiler dependency."""
from __future__ import annotations

import json
import operator
import os
import re
import sys
import tempfile
import zipfile
from pathlib import Path, PurePosixPath

from orbit_stdlib import BUILTINS, LIBRARY_FUNCTIONS

FORMAT = "ORBIT-BEAM-2"
ROOT = Path(__file__).resolve().parents[1]
LIBS = ROOT / "libraries"


class OrbitRuntimeError(Exception):
    """An application or BEAM runtime error."""


_BINARY = {
    "+": operator.add, "-": operator.sub, "*": operator.mul,
    "/": operator.truediv, "%": operator.mod,
    "==": operator.eq, "!=": operator.ne,
    "in": lambda a, b: operator.contains(b, a),
    "<": operator.lt, "<=": operator.le, ">": operator.gt, ">=": operator.ge,
    "and": lambda a, b: bool(a) and bool(b), "&&": lambda a, b: bool(a) and bool(b),
    "or": lambda a, b: bool(a) or bool(b), "||": lambda a, b: bool(a) or bool(b),
}


def _safe_archive_name(name: str) -> bool:
    path = PurePosixPath(name)
    return not path.is_absolute() and ".." not in path.parts and "\\" not in name


def _lux_parse(path: Path) -> dict:
    if path.suffix != ".lux" or not path.is_file():
        raise OrbitRuntimeError(f"Lux library not found: {path}")
    lines = [line.strip() for line in path.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    if not lines or lines[0] != "LUX-LIBRARY 01":
        raise OrbitRuntimeError(f"{path.name}: invalid Lux header")
    data = {"MODULE": [], "EXPORT": []}
    for line in lines[1:]:
        key, _, value = line.partition(" ")
        if not value:
            raise OrbitRuntimeError(f"{path.name}: malformed metadata")
        if key in ("MODULE", "EXPORT"):
            data[key].append(value)
        elif key in ("NAME", "VERSION", "STATUS", "DESCRIPTION", "NAMESPACE", "SOURCE"):
            if key in data:
                raise OrbitRuntimeError(f"{path.name}: duplicate {key}")
            data[key] = value
        else:
            raise OrbitRuntimeError(f"{path.name}: unknown field {key}")
    if not all(key in data for key in ("NAME", "VERSION", "STATUS")) or not data["MODULE"]:
        raise OrbitRuntimeError(f"{path.name}: missing required metadata")
    if not re.fullmatch(r"\d+\.\d+\.\d+", data["VERSION"]):
        raise OrbitRuntimeError(f"{path.name}: invalid semantic version")
    return data


def _load_custom_library(metadata: dict, lux_path: Path, cwd: Path, functions: dict, line: int):
    if not metadata.get("SOURCE"):
        return
    if not metadata.get("NAMESPACE"):
        raise OrbitRuntimeError(f"Line {line}: custom Lux libraries with SOURCE must declare NAMESPACE")
    source_rel = PurePosixPath(metadata["SOURCE"])
    if source_rel.is_absolute() or ".." in source_rel.parts or "\\" in metadata["SOURCE"]:
        raise OrbitRuntimeError(f"Line {line}: unsafe custom library SOURCE path")
    source_path = (lux_path.parent / Path(*source_rel.parts)).resolve()
    if not source_path.is_relative_to(lux_path.parent.resolve()):
        raise OrbitRuntimeError(f"Line {line}: custom library source escapes its lib folder")

    # Custom libraries are compiled by orbitpkg at app-build time. Nano only reads BEAM.
    beam_path = source_path.with_suffix(".beam")
    if not beam_path.is_file():
        raise OrbitRuntimeError(
            f"Line {line}: compiled custom library is missing ({beam_path.name}); "
            "rebuild the .orbit app with Orbit SDK 1.3.0 or newer"
        )
    try:
        module_program = json.loads(beam_path.read_text(encoding="utf-8"))
    except Exception as exc:
        raise OrbitRuntimeError(f"Line {line}: invalid custom library BEAM: {exc}") from exc
    if module_program.get("format") != FORMAT:
        raise OrbitRuntimeError(f"Line {line}: custom library BEAM uses an incompatible format")
    if module_program.get("code") != [{"op": "HALT", "arg": None, "line": 0}]:
        raise OrbitRuntimeError(f"Line {line}: custom library source may contain function definitions only")
    module_functions = module_program.get("functions", {})
    exports = metadata.get("EXPORT", []) or list(module_functions)
    missing = [name for name in exports if name not in module_functions]
    if missing:
        raise OrbitRuntimeError(f"Line {line}: custom library exports undefined function(s): {', '.join(missing)}")
    namespace = metadata["NAMESPACE"]
    for local_name, fn_data in module_functions.items():
        copied = {"params": list(fn_data["params"]), "code": [dict(ins) for ins in fn_data["code"]]}
        for ins in copied["code"]:
            if ins.get("op") == "CALL" and ins.get("arg", {}).get("name") in module_functions:
                ins["arg"]["name"] = namespace + "." + ins["arg"]["name"]
        functions[namespace + "." + local_name] = copied


def run_program(program: dict, cwd=None, output=None, max_steps: int = 5_000_000):
    """Execute compiled Orbit BEAM without importing the compiler."""
    if program.get("format") != FORMAT:
        raise OrbitRuntimeError("Unsupported BEAM format")
    target = Path(cwd).resolve() if cwd is not None else None
    previous = os.getcwd()
    if target is not None:
        os.chdir(target)
    try:
        functions = dict(program.get("functions", {}))
        stack = []
        steps = 0
        global_frame = {"code": program["code"], "ip": 0, "env": {}, "const": set(),
                        "parent": None, "base": 0, "name": "<main>"}
        frames = [global_frame]
        emit = output if output is not None else print

        def find(frame, name):
            current = frame
            while current is not None:
                if name in current["env"]:
                    return current
                current = current["parent"]
            return None

        while frames:
            frame = frames[-1]
            if frame["ip"] >= len(frame["code"]):
                frames.pop()
                if frames:
                    del stack[frame["base"]:]
                    stack.append(None)
                continue
            instruction = frame["code"][frame["ip"]]
            frame["ip"] += 1
            op, arg, line = instruction["op"], instruction.get("arg"), instruction.get("line", 0)
            steps += 1
            if steps > max_steps:
                raise OrbitRuntimeError("Execution step limit exceeded (possible infinite loop)")
            try:
                if op == "CONST":
                    stack.append(arg)
                elif op == "LOAD":
                    owner = find(frame, arg)
                    if owner is None:
                        raise OrbitRuntimeError(f"Line {line}: undefined variable {arg!r}")
                    stack.append(owner["env"][arg])
                elif op == "DECLARE":
                    value = stack.pop(); name = arg["name"]
                    if name in frame["env"]:
                        raise OrbitRuntimeError(f"Line {line}: {name!r} already declared in this scope")
                    frame["env"][name] = value
                    if arg["constant"]:
                        frame["const"].add(name)
                elif op == "STORE":
                    owner = find(frame, arg)
                    if owner is None:
                        raise OrbitRuntimeError(f"Line {line}: undefined variable {arg!r}")
                    if arg in owner["const"]:
                        raise OrbitRuntimeError(f"Line {line}: cannot assign to constant {arg!r}")
                    owner["env"][arg] = stack.pop()
                elif op == "POP":
                    stack.pop()
                elif op == "BUILD_LIST":
                    count = arg; values = stack[-count:] if count else []
                    if count:
                        del stack[-count:]
                    stack.append(values)
                elif op == "GET_ITEM":
                    index = stack.pop(); obj = stack.pop(); stack.append(obj[index])
                elif op == "DUP":
                    stack.append(stack[-1])
                elif op == "DUP_PAIR":
                    index = stack.pop(); obj = stack.pop(); stack.extend([obj, index, obj, index])
                elif op == "SET_ITEM":
                    value = stack.pop(); index = stack.pop(); obj = stack.pop(); obj[index] = value; stack.append(value)
                elif op == "GET_ATTR":
                    obj = stack.pop(); stack.append(obj[arg] if isinstance(obj, dict) else getattr(obj, arg))
                elif op == "SET_ATTR":
                    value = stack.pop(); obj = stack.pop()
                    if isinstance(obj, dict): obj[arg] = value
                    else: setattr(obj, arg, value)
                    stack.append(value)
                elif op == "BUILD_MAP":
                    count = arg; pairs = stack[-2 * count:] if count else []
                    if count:
                        del stack[-2 * count:]
                    stack.append({pairs[i]: pairs[i + 1] for i in range(0, len(pairs), 2)})
                elif op == "ITER_INIT":
                    frame["env"]["__iter_" + arg] = iter(stack.pop())
                elif op == "ITER_NEXT":
                    try:
                        frame["env"]["__iter_" + arg["name"]] = next(frame["env"]["__iter_" + arg["name"]])
                    except StopIteration:
                        frame["ip"] = arg["target"]
                elif op == "LOAD_NANO":
                    # Packaging directive; evaluates to null for stack consistency.
                    stack.append(None)
                elif op == "LOAD_LIB":
                    spec = arg
                    if spec.startswith("orbit.") and not spec.endswith(".lux"):
                        spec += ".lux"
                    if spec.startswith("orbit."):
                        if not re.fullmatch(r"orbit\.[A-Za-z_][A-Za-z0-9_.]*\.lux", spec):
                            raise OrbitRuntimeError(f"Line {line}: invalid built-in Lux library reference {spec!r}")
                        embedded_libs = (target / "nano" / "libraries") if target is not None else None
                        candidate = (embedded_libs / spec) if embedded_libs is not None else None
                        if candidate is not None and candidate.is_file():
                            lux_path = candidate.resolve()
                            if not lux_path.is_relative_to(embedded_libs.resolve()):
                                raise OrbitRuntimeError(f"Line {line}: embedded Lux path is invalid")
                        else:
                            lux_path = (LIBS / spec).resolve()
                            if not lux_path.is_relative_to(LIBS.resolve()):
                                raise OrbitRuntimeError(f"Line {line}: built-in Lux path is invalid")
                    elif spec.startswith("lib/") and target is not None:
                        rel = PurePosixPath(spec)
                        if rel.is_absolute() or ".." in rel.parts or "\\" in spec:
                            raise OrbitRuntimeError(f"Line {line}: unsafe application Lux path")
                        lux_path = (target / Path(*rel.parts)).resolve()
                        if not lux_path.is_relative_to(target):
                            raise OrbitRuntimeError(f"Line {line}: application Lux path escapes project")
                    else:
                        raise OrbitRuntimeError(f"Line {line}: invalid Lux library reference {spec!r}")
                    metadata = _lux_parse(lux_path)
                    _load_custom_library(metadata, lux_path, target or Path.cwd(), functions, line)
                elif op == "UNARY":
                    value = stack.pop()
                    stack.append((not bool(value)) if arg in ("!", "not") else (-value if arg == "-" else +value))
                elif op == "BINARY":
                    right = stack.pop(); left = stack.pop(); stack.append(_BINARY[arg](left, right))
                elif op == "CALL":
                    count = arg["argc"]; args = stack[-count:] if count else []
                    if count:
                        del stack[-count:]
                    name = arg["name"]
                    if name in functions:
                        function = functions[name]; params = function["params"]
                        if len(args) != len(params):
                            raise OrbitRuntimeError(f"Line {line}: {name} expects {len(params)} arguments, got {len(args)}")
                        local = dict(zip(params, args))
                        frames.append({"code": function["code"], "ip": 0, "env": local, "const": set(),
                                       "parent": frame, "base": len(stack), "name": name})
                    else:
                        if name in ("signal", "print"):
                            if len(args) != 1:
                                raise OrbitRuntimeError(f"Line {line}: {name} expects exactly one argument")
                            emit(args[0]); stack.append(None); continue
                        function = BUILTINS.get(name) or LIBRARY_FUNCTIONS.get(name)
                        if function is None:
                            raise OrbitRuntimeError(f"Line {line}: unknown function {name!r}; load its Lux library and check the API name")
                        result = function(*args)
                        if name == "console.read_line":
                            result = str(result)
                        stack.append(result)
                elif op == "JUMP_FALSE":
                    if not stack.pop(): frame["ip"] = arg
                elif op == "JUMP":
                    frame["ip"] = arg
                elif op == "RETURN":
                    result = stack.pop() if stack else None
                    frames.pop()
                    if frames:
                        del stack[frame["base"]:]
                        stack.append(result)
                    else:
                        return result
                elif op == "HALT":
                    return None
                else:
                    raise OrbitRuntimeError(f"Unknown opcode {op}")
            except OrbitRuntimeError:
                raise
            except Exception as exc:
                raise OrbitRuntimeError(f"Line {line}: {type(exc).__name__}: {exc}") from exc
        return None
    finally:
        os.chdir(previous)


def run_package(package_path: str | Path):
    """Safely extract and run one .orbit package using only the compact VM."""
    package = Path(package_path).resolve()
    if package.suffix != ".orbit" or not package.is_file():
        raise OrbitRuntimeError("Orbit Nano expects an existing .orbit application package")
    with zipfile.ZipFile(package) as archive:
        infos = archive.infolist()
        if len(infos) > 10000 or sum(info.file_size for info in infos) > 256 * 1024 * 1024:
            raise OrbitRuntimeError("Application package exceeds Orbit Nano's extraction limits")
        if any(not _safe_archive_name(info.filename) for info in infos):
            raise OrbitRuntimeError("Application package contains an unsafe path")
        names = {info.filename for info in infos}
        if "orbit.json" not in names or "main.beam" not in names:
            raise OrbitRuntimeError("Invalid .orbit package")
        manifest = json.loads(archive.read("orbit.json"))
        program = json.loads(archive.read("main.beam"))
        if program.get("format") != FORMAT:
            raise OrbitRuntimeError("Application uses an incompatible Orbit VM format")
        with tempfile.TemporaryDirectory(prefix="orbit-nano-") as temp_dir:
            app_root = Path(temp_dir) / "app"
            app_root.mkdir(parents=True, exist_ok=True)
            for info in infos:
                target = (app_root / Path(*PurePosixPath(info.filename).parts)).resolve()
                if not target.is_relative_to(app_root.resolve()):
                    raise OrbitRuntimeError("Application package contains an unsafe path")
                if info.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                    continue
                target.parent.mkdir(parents=True, exist_ok=True)
                with archive.open(info) as source, target.open("wb") as destination:
                    while True:
                        chunk = source.read(1024 * 1024)
                        if not chunk:
                            break
                        destination.write(chunk)
            return run_program(program, cwd=app_root)
