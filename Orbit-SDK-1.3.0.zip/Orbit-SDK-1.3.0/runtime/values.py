"""Runtime value classification helpers."""
from runtime.stdlib.debug import type_of

def is_number(value): return isinstance(value,(int,float)) and not isinstance(value,bool)
def is_integer(value): return isinstance(value,int) and not isinstance(value,bool)
def is_string(value): return isinstance(value,str)
def is_list(value): return isinstance(value,list)
def is_object(value): return isinstance(value,dict)
__all__=["type_of","is_number","is_integer","is_string","is_list","is_object"]
