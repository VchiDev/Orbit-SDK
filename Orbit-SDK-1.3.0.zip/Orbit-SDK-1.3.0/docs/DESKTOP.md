# Orbit Desktop APIs

The optional desktop bridge uses Python Tkinter. It can create a native host window, labels, buttons, text entries and checkboxes. This is real desktop integration but remains a small toolkit adapter rather than a complete cross-platform UI framework.

```orbit
lux.loadLib(orbit.desktop.lux)
var app = window.create("Orbit Notes", 640, 420)
window.label(app, "Hello from Orbit", 24, 24)
var title = ui.entry(app, 24, 64, 280)
ui.text_set(title, "First note")
window.run(app)
```

Run with a Python distribution that includes Tkinter in an interactive desktop session. Some Linux distributions package Tkinter separately. Headless CI environments cannot display windows; use software graphics and console output there.

Current limitations include no full layout engine, native menus/dialogs, accessibility certification, DPI scaling system, multi-window event loop abstraction, platform-specific packaging, or rich text editor.
