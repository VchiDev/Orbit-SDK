# Orbit Office Library Foundation

The `orbit.office` library offers programmatic document, spreadsheet and presentation models.

- Documents: paragraphs/headings/tables; HTML export.
- Spreadsheets: A1-style cell storage; CSV export; arithmetic formulas, cell references, `SUM(range)`, and `AVERAGE(range)`.
- Presentations: title/body slides; HTML slide-deck export.
- PDF: minimal one-page text-only PDF export.

Example:

```orbit
lux.loadLib(orbit.office.lux)
var report = office.document("Quarterly Report", "Analyst")
office.heading(report, "Overview", 1)
office.paragraph(report, "Generated using Orbit.")
office.export_html(report, "build/report.html")
var sheet = office.sheet(50, 12)
office.cell_set(sheet, "A1", 12)
office.cell_set(sheet, "A2", 30)
office.cell_set(sheet, "A3", "=SUM(A1:A2)")
signal(office.cell_get(sheet, "A3"))
office.export_csv(sheet, "build/data.csv")
```

This library is not a full office suite. It does not implement DOCX/XLSX/PPTX compatibility, advanced formulas, styles, embedded objects, charts, comments, macros, pagination, print drivers, or PDF import.
