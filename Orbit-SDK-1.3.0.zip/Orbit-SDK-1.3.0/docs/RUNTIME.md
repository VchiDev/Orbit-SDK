# Orbit Runtime 1.3.0

The full SDK VM executes `ORBIT-BEAM-2` programs from the existing Orbit compiler. It uses a value stack and call frames. Each frame has bytecode, an instruction pointer, local variables, immutable-binding metadata and a link to the calling frame for global reads. Calls dispatch either to Orbit-defined functions or to the registered host library. The VM checks for undefined names, immutable assignment, invalid operations and an instruction-count ceiling.

The full VM is available through `orbitvm` and the `orbit run` command. `runtime/compact_vm.py` is a separate BEAM-only runtime used by Orbit Nano; it deliberately does not import the compiler or developer CLI. Nano receives only the built-in implementation modules selected by the app's Lux dependency list. App-local custom Lux libraries remain in the `.orbit` archive under `lib/`, with `.lux` metadata, `.orb` source and a precompiled `.beam` module.

Both runtimes are implemented in Python and require Python 3.10+. They are not native executables, a sandbox, a garbage-collected native heap, a concurrent/async scheduler, or a bytecode optimizer. Host library functions run with the permissions of the current OS user. Treat untrusted `.orb`, `.beam`, `.orbit` and Nano packages as untrusted programs.
