# Orbit SDK Architecture 1.3.0

## Runtime pipeline

```text
.orb source
   │
   ▼
compiler/lexer.py       Tokenization (public API; implementation in orbit_tool.py)
   │
   ▼
compiler/parser.py     Recursive-descent parsing and AST (public API)
   │
   ▼
compiler/bytecode.py   BEAM-2 bytecode generation
   │
   ▼
.beam program           JSON bytecode + function table
   │
   ▼
runtime/vm.py           Full SDK VM façade
   │
   ├── runtime/stdlib/   Host implementations for built-in Lux libraries
   ├── engine/flux/      Scene simulation, software renderer and live game window
   ├── desktop/          Optional Tk desktop application bridge
   └── office/           Document, spreadsheet, presentation and PDF helpers

.orbit app package
   │
   ▼
Orbit Nano
   ├── runtime/compact_vm.py    BEAM-only VM; no compiler
   ├── selected built-in APIs   Copied into Nano's runtime
   └── app/<name>.orbit         App keeps custom Lux files in its own lib/ folder
```

`orbit_tool.py` remains the compatibility façade and primary CLI. The compiler and full VM are retained; Nano uses the separate compact VM so players do not receive the compiler.

## Actual SDK structure

```text
Orbit-SDK-1.3.0/
├── README.md, VERSION, CHANGELOG.md, LICENSE
├── orbit_tool.py                 Existing compiler, VM, CLI, Lux and package commands
├── orbit_stdlib.py               Namespace-to-host-function registry
├── install.ps1, install.sh, uninstall.ps1
├── bin/                          orbit, orbitc, orbitvm, orbitpkg, orbitnano, lux launchers
├── compiler/                     Public lexer/parser/bytecode/diagnostic APIs
├── runtime/
│   ├── vm.py, compact_vm.py       Full-SDK façade and Nano-only BEAM VM
│   ├── values.py, functions.py    Runtime value/function helpers
│   └── stdlib/                   Implementations for the built-in Lux libraries
├── package_manager/              Manifest validator, Lux resolver, builder and inspector
├── libraries/                    Versioned Lux manifests for built-in libraries
├── engine/flux/                  Scenes, entities, movement, collision and live Tk game loop
├── desktop/                      Tk window, widgets and input adapters
├── office/                       Document, spreadsheet, presentation and PDF helpers
├── tools/                         Formatter, bytecode trace debugger and profiler helpers
├── docs/                          Language, library, architecture and subsystem guides
├── examples/                      Language, library, graphics, playable game and office samples
├── templates/                     Console-app and playable Flux game starter projects
└── tests/                          Unit and integration tests
```

## Compiler and language status

| Component | Implemented in 1.3.0 | Not implemented in this release |
|---|---|---|
| Lexer/parser | UTF-8 source, comments, literals, expressions, functions, blocks, lists/maps, index/member access and assignment, if/else, while, for/in, break/continue | classes, generics, type declarations, lambdas, macros |
| Bytecode | constants, variable loads/stores, calls, functions, jumps, collections, return, library load | optimizer, debug symbols, exception handlers |
| Full SDK VM | stack, function frames, global reads, host calls, execution limit | async scheduler, coroutine system |
| Nano VM | BEAM execution, function calls, built-in host APIs, app-local compiled Lux modules | compiler and development tools (intentionally excluded) |
| Packages | `.orbit` ZIP, manifest, compiled entry, assets, app-local `lib/`, custom library BEAM and archive path checks | package registry, signatures, delta updates |

## Engine and library boundaries

Flux Engine has a live 2D desktop game loop: it opens a window, updates a scene at a target frame rate, handles keyboard/pointer input, moves controlled entities, checks collectible collisions and renders each frame. `flux.render(scene, canvas)` remains the separate off-screen, one-frame renderer used for screenshots and headless asset generation. The live display uses Tkinter and therefore requires Tkinter plus an active desktop session.

The graphics library is a CPU RGBA software renderer with PNG output. `graphics3d` supports simple mesh transforms, perspective projection, flat-shaded CPU polygons and wireframes; it is a lightweight 3D utility, not a hardware-accelerated engine. Physics supplies body integration and 2D collision helpers. Audio can synthesize WAV clips and delegate playback to a host utility. Desktop/window/UI APIs use Tkinter. Office APIs provide document, spreadsheet, presentation and basic PDF workflows, not full DOCX/XLSX/PPTX compatibility. Networking is synchronous HTTP/HTTPS with bounded response sizes. SQLite uses Python's standard-library SQLite driver.

## Lux and application distribution

A built-in `.lux` manifest declares a library whose implementation is part of the Orbit SDK. When building Nano, only the built-in libraries referenced by the app (including dependencies of custom library modules) are copied into Nano's runtime. A custom Lux library is app-owned: the `.lux` manifest, `.orb` source and generated `.beam` file are kept under `lib/` inside the `.orbit` archive. Nano loads those custom modules from the app package without moving them into its shared built-in runtime.

All 22 built-in Lux manifests have matching runtime implementations. `desktop`, `input`, `ui` and `window` are marked optional-host because their interactive functionality needs a Tk-capable GUI environment; their APIs remain available for headless-safe queries where documented.

The SDK is focused on practical everyday software and indie games. API documentation identifies supported behavior and host requirements; it does not imply that every API is available in every headless or restricted environment.
