# Orbit Language 1.3.0

## File formats and execution

- `.orb` — UTF-8 source code.
- `.beam` — JSON-based Orbit bytecode (`ORBIT-BEAM-2`) executed by the Orbit VM.
- `.lux` — Lux library metadata, module names and (for custom libraries) source/namespace/export declarations.
- `.orbit` — ZIP-based application package containing `orbit.json`, `main.beam`, assets and any app-local `lib/` files.

The Orbit compiler tokenizes and parses `.orb` source and emits `.beam`; `orbitvm` executes `.beam` in the existing Orbit VM.

## Lexical rules

- Identifiers start with an ASCII letter or `_`, followed by letters, digits or `_`.
- `//` and `#` start a line comment outside a string.
- Strings use single or double quotes and Python-style backslash escapes. String interpolation is not supported.
- Numeric literals are decimal integers and decimal floating-point numbers.
- Newlines or `;` separate statements. `{` and `}` delimit blocks.
- Keywords are `var`, `let`, `const`, `fn`, `function`, `return`, `if`, `else`, `while`, `for`, `in`, `break`, `continue`, `true`, `false`, and `null`.

## Values and bindings

Supported values are `null`, booleans, integers, floating-point numbers, strings, lists and objects/dictionaries. `var` and `let` create mutable bindings; `const` creates a binding that cannot be reassigned.

```orbit
const APP_NAME = "Orbit Notes"
let ready = true
var count = 0
var scores = [10, 20, 30]
var profile = {name: "Orbit", active: true}

count += 1
scores[0] = 15
profile.name = "Orbit Studio"
signal(profile["name"])
```

Lists use zero-based integer indexes. Objects support string-key access (`profile["name"]`) and member shorthand (`profile.name`). Indexed and member assignment are supported, including `+=`, `-=`, `*=`, and `/=`. Direct declaration type annotations are not part of this release.

## Expressions and operators

Unary: `!`, `not`, unary `+`, unary `-`.

Arithmetic: `+`, `-`, `*`, `/`, `%`.

Comparison and membership: `==`, `!=`, `<`, `<=`, `>`, `>=`, `in`.

Boolean: `and`, `or`, `&&`, `||`.

Parentheses group expressions. Multiplication/division/modulo bind more tightly than addition/subtraction; comparisons bind less tightly than arithmetic; boolean AND binds more tightly than boolean OR. Boolean AND/OR use short-circuit evaluation.

```orbit
var level = 4
var unlocked = level >= 3 and level < 10
if unlocked or level == 0 {
    signal("Unlocked")
}
```

## Functions

Functions are defined with `fn` or `function`, accept positional arguments and return a value with `return`. Recursion is supported.

```orbit
fn square(value) {
    return value * value
}

fn sum(items) {
    var result = 0
    for item in items {
        result += item
    }
    return result
}

signal(square(9))
signal(sum([1, 2, 3, 4]))
```

Function parameters and local bindings are scoped to the function. A function can read global bindings. Closures, nested lexical captures, default parameters, named arguments, function values, lambdas, overloads and nested functions are not supported in this release.

## Conditions and loops

```orbit
var count = 0
if count == 0 {
    signal("starting")
} else if count < 0 {
    signal("negative")
} else {
    signal("positive")
}

while count < 10 {
    count += 1
    if count == 3 { continue }
    if count == 8 { break }
}

for item in ["red", "green", "blue"] {
    signal(item)
}
```

`break` exits the nearest loop and `continue` advances to the next iteration. `range(stop)`, `range(start, stop)` and `range(start, stop, step)` are available as a built-in function. An instruction limit protects the VM from accidental infinite loops.

## Built-in functions

`signal(value)` and `print(value)` write one value to standard output. The core functions are `len`, `str`, `int`, `float`, `bool`, `type`, `abs`, `min`, `max`, `round`, and `range`.

## Lux libraries

```orbit
lux.loadLib(orbit.math.lux)
lux.loadLib(orbit.graphics.lux)
signal(math.sqrt(81))
var frame = graphics.canvas(320, 180, "#18243a")
graphics.rect(frame, 20, 20, 100, 60, "#ff8800")
graphics.save_png(frame, "build/frame.png")
```

App-local custom libraries load with `lux.loadLib("lib/custom.lux")`. Built-in references use the `orbit.<library>.lux` name. Lux loading validates the manifest and records the dependency; it is not a security sandbox or per-function capability gate.

## Not in the current grammar

Classes, structs, inheritance, generics, type declarations, enums, exceptions/`try`, switch/match, lambdas, closures, async/await, coroutines, macros, modules/import statements outside Lux, string interpolation, ternary expressions, and first-class function references are not supported in 1.3.0. Use dictionaries and custom Lux libraries for reusable data and code.

## Runtime and safety model

Compiler errors include source line/column locations where available. VM errors include the failing source line. Programs execute with the host user's filesystem/network permissions and are not sandboxed. Treat untrusted `.orb`, `.beam` and `.orbit` files as untrusted programs.

## Embedded runtime directive

`orbit.LoadNano()` is a zero-argument build directive. It emits a `LOAD_NANO` marker that is a no-op during ordinary source execution. `orbitpkg build` detects the marker and embeds a compact dependency-selected Orbit Nano runtime and metadata in the resulting `.orbit` archive.
