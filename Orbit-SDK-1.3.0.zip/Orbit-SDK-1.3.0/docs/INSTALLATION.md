# Installation and distribution

## Install the full SDK — Windows PowerShell

```powershell
Set-ExecutionPolicy -Scope Process Bypass
.\install.ps1
```

Close and reopen PowerShell so the updated user PATH is loaded. Verify the compiler, VM, package tools and Lux registry:

```powershell
orbit --version
orbitc --version
orbitvm --version
orbitpkg --version
orbitnano --version
lux list
```

To remove the SDK's PATH entry (the SDK folder is not deleted):

```powershell
.\uninstall.ps1
```

Python 3.10+ must already be installed and available as `python`; the installer does not install Python.

## Linux/macOS

```sh
chmod +x ./install.sh
./install.sh
```

The script adds the SDK `bin` directory to `~/.profile` if it is not already present. Open a new shell or source the profile. Tk desktop and Flux game windows require Tkinter and a graphical session. Audio playback requires the platform player used by the runtime (`aplay` on Linux or `afplay` on macOS); WAV generation does not.

## Distribute an app without the full SDK

Build an `.orbit` package with the full SDK and make a compact player bundle:

```sh
orbitpkg build ./MyApp
orbitnano build ./MyApp/MyApp.orbit -o ./MyApp-Nano.zip
```

Nano contains the BEAM-only VM and the built-in library implementation modules used by that app. Custom Lux manifests, source and compiled BEAM stay inside the application's `lib/` directory in the `.orbit` package. Nano does not contain the compiler. This release of Nano is a Python source-runtime bundle and requires Python 3.10+ on the player's device; it is not a self-contained native executable.
