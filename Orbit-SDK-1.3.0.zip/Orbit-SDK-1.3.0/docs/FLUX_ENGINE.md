# Flux Engine 1.3.0

Flux Engine is Orbit's practical indie-game engine. The primary gameplay API is a real-time, windowed 2D loop. A separate deterministic software renderer remains available for offline screenshots and asset generation.

## A playable game

```orbit
lux.loadLib(orbit.fluxengine.lux)
var game = flux.scene("Crystal Hunt", "#17243b")
flux.entity(game, "Meadow", 0, 280, 640, 80, "#355b43", "rect")
var player = flux.entity(game, "Player", 60, 160, 34, 48, "#ffcc66", "rect")
flux.control(game, player, 220, "arrows_wasd")
flux.collectible(game, "Gem A", 220, 120, 22, "#65e8ff")
flux.collectible(game, "Gem B", 480, 220, 22, "#c4b5fd")
flux.goal(game, 2, "All gems collected!")
flux.run(game, 640, 360, "Crystal Hunt", 60)
```

Run the source with `orbit run src/main.orb` or package it with `orbitpkg build .` and run the result with `orbitpkg run .\MyGame.orbit`. `flux.run` opens a native game window and starts the frame loop. Arrow keys and WASD move a controlled entity; diagonal movement is normalized; collectibles increment the score; a goal message appears when the target count is reached. Escape or the window close button exits.

## Scene API

- `flux.scene(name, background)` — create a scene record.
- `flux.entity(scene, name, x, y, width, height, color, shape)` — add a visible rectangle, circle, line or text entity.
- `flux.velocity(entity, vx, vy)` — set continuous velocity.
- `flux.control(scene, player, speed, scheme)` — enable arrow-key/WASD movement (`arrows`, `wasd`, `arrows_wasd`).
- `flux.collectible(scene, name, x, y, size, color)` — create a collectable circle.
- `flux.goal(scene, count, message)` — set the required collection count and win message.
- `flux.label(scene, text, x, y, color, size)` — add a HUD label.
- `flux.set_bounds(scene, enabled)` — keep the controlled player inside the game window.
- `flux.update(scene, dt, gravity)` — advance the scene manually; delta time is clamped to 0.25 seconds.
- `flux.render(scene, canvas)` — render one frame to a `graphics` canvas.
- `flux.find`, `flux.remove`, `flux.collide` — entity lookup, removal and AABB collision test.
- `flux.run(scene, width, height, title, fps)` — interactive display and loop; default 60 FPS, supported range 15–144.

## Real game window versus PNG rendering

`flux.run(...)` is the play mode: it creates a native window, continuously updates the world, polls keyboard and pointer state, handles movement and collectible collisions, and renders every frame. `flux.render(scene, canvas)` is different: it draws exactly one off-screen frame into a software canvas. Use `graphics.save_png` after `flux.render` for screenshots, automated asset generation, thumbnails or headless CI. A script that only calls `flux.scene`, `flux.render` and `graphics.save_png` does not launch a playable game because it did not call `flux.run`.

## Display requirements

Interactive play requires Python's Tkinter module and a graphical desktop session. On Linux, Tkinter may need to be installed as the OS package `python3-tk`; on Windows, use a Python distribution that includes Tcl/Tk. Headless servers can still use the PNG renderer. Flux does not silently substitute a PNG when a window cannot be opened; it returns an actionable runtime error.

Flux 1.2 is a practical 2D indie-game engine. It includes the playable desktop loop and basic scene/entity systems, but does not yet include a visual editor, sprite-atlas importer, full animation state machine, built-in real-time audio mixer, multiplayer stack or integrated rigid-body physics solver. The `graphics3d` library offers CPU mesh and triangle rendering for simple 3D scenes, but it is not yet integrated into the Flux 2D scene loop.
