# Orbit application packages and Orbit Nano

An `.orbit` file is a ZIP-based application package containing `orbit.json`, `main.beam`, assets and application-local `lib/` files.

## Build and run

```powershell
orbitpkg build .
orbitpkg inspect .\MyApp.orbit
orbitpkg run .\MyApp.orbit
```

The package manifest records `runtime_dependencies.built_in` and `runtime_dependencies.custom`. Built-in library implementation code is supplied by the Orbit runtime. App-local libraries are copied into the `.orbit` archive under `lib/`.

## Orbit Nano

Orbit Nano is a compact runtime for playing/running an application without installing the full Orbit SDK. Build it from an existing `.orbit` package:

```powershell
orbitnano build .\MyGame.orbit -o .\MyGame-Nano.zip
```

or use `orbit nano build ...`. The output ZIP contains a small runtime, the bytecode VM, only the standard-library implementation modules required by the app's declared built-in Lux dependencies, and the app package. The app package retains its custom libraries in `lib/`; custom libraries are not copied into the shared Nano built-in library set. Built-in Lux manifests are installed into the Nano runtime's `libraries/` directory. The compiler is not included.

The current Nano distribution is a compact Python source-runtime bundle and requires Python 3.10+. It is not a native single-file executable. Extract the ZIP and run `python run.py`, `run.ps1`, or `run.bat`.

## Security

Archives are checked for absolute paths, parent traversal and Windows-style path separators before extraction. Custom Lux `SOURCE` paths are restricted to the app's own `lib/` directory. Orbit applications still execute with the host user's normal filesystem/network permissions; package safety checks are not an application sandbox.
