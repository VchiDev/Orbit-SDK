# Compiler API

Python API:

```python
from compiler.lexer import lex
from compiler.parser import Parser
from compiler.bytecode import compile_source, write_beam

source = 'fn twice(x) { return x * 2 }\nsignal(twice(21))'
program = compile_source(source)
write_beam(program, 'app.beam')
```

The parser is a recursive-descent parser. Bytecode has an instruction list and a function table. `ORBIT-BEAM-2` is the current format and is intentionally human-inspectable JSON.
