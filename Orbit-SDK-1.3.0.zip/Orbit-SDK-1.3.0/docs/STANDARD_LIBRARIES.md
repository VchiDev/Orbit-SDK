# Orbit Standard Libraries 1.3.0

All functions below are callable from Orbit source using the shown namespace. The Python modules implementing these APIs live in `runtime/stdlib/`, `engine/flux/`, and `office/`. The APIs use normal Orbit values (numbers, strings, lists and dictionaries). Some calls return host objects such as windows, canvases, database connections and Flux scene records; keep these in variables and pass them to subsequent calls.

## Console — `orbit.console`

`console.write(value)`, `console.log(value)`, `console.read_line(prompt)`, `console.clear()`, `console.color(value, ansi_code)`. `signal(value)` is the simple newline output built-in.

## Math — `orbit.math`

`math.sin/cos/tan/asin/acos/atan/atan2/sqrt/floor/ceil/log/log10/exp`, `math.vec2(x,y)`, `math.vec3(x,y,z)`, `math.dot(a,b)`, `math.length(v)`, `math.normalize(v)`, `math.distance(a,b)`, `math.lerp(a,b,t)`, `math.clamp(x,min,max)`, `math.map_range(x,in_min,in_max,out_min,out_max)`, `math.radians`, `math.degrees`, `math.random()`, `math.random_int(min,max)`, `math.pi()`, `math.tau()`, `math.e()`, `math.hypot(x,y)`, and `math.is_finite(value)`.

## Text — `orbit.text`

`text.upper/lower/trim/split/join/replace/contains/starts_with/ends_with/substring/format/normalize_unicode/matches/regex_find_all/codepoints/from_codepoints`.

## Data — `orbit.data`

`data.json_parse`, `data.json_stringify(value, pretty)`, `data.csv_parse`, `data.csv_stringify`, Base64 encode/decode, `data.keys`, `data.values`, `data.has`, `data.merge`, `data.sort`, `data.unique`, `data.push`, `data.pop`, `data.contains`.

## Files — `orbit.files`

`files.exists`, `is_file`, `is_dir`, `read_text`, `write_text`, `read_bytes`, `write_bytes`, `append_text`, `mkdir`, `list_dir`, `copy`, `move`, `remove`, `join`, `name`, `extension`, and `sha256`. Relative paths resolve from the program's working directory. The runtime does not sandbox filesystem access.

## Time — `orbit.time`

`time.now()`, `time.unix()`, `time.timestamp()`, `time.date_string()`, `time.sleep(seconds)`, `time.measure_start()`, `time.elapsed(start)`, and `time.format_timestamp(timestamp, format)`.

## System — `orbit.system`

`system.os_name`, `os_version`, `architecture`, `python_version`, `cwd`, `env(name, default)`, `set_env(name,value)`, `args`, `home`, and `newline`.

## Security — `orbit.security`

`security.sha256`, `sha512`, `hmac_sha256(key,message)`, `secure_token(length)`, `random_bytes(length)`, `constant_time_equal(a,b)`, and Base64 helpers. These utilities do not replace a reviewed application security design or secure secret storage.

## Networking — `orbit.network`

`network.get(url, timeout)`, `network.post(url, body, content_type, timeout)`, `network.head(url, timeout)`, and `network.download(url,path,timeout)`. Only absolute HTTP/HTTPS URLs are accepted. Responses are capped at 2 MiB. The client does not yet offer async I/O, WebSockets, a TCP server, TLS certificate customization, or a connection pool.

## Database — `orbit.database`

`database.open_database(path)`, `database.execute(db, sql, params)`, `database.query(db, sql, params)`, `database.table_exists(db,name)`, and `database.close(db)`. Uses Python's SQLite engine. Use parameter placeholders (`?`) for data values instead of concatenating SQL input.

## Graphics 2D — `orbit.graphics`

`graphics.canvas(width,height,background)`, `clear`, `pixel`, `pixel_get`, `rect(canvas,x,y,w,h,color,filled,thickness)`, `line`, `circle`, `polygon`, `text`, and `save_png(canvas,path)`. The renderer uses an RGBA byte buffer and exports standards-compliant PNG files using zlib. Colors use `#RRGGBB`, `#RRGGBBAA`, common named colors, or RGB(A) lists. Canvas size is limited to 4096×4096. Text uses a small built-in 5×7 bitmap font.

## Graphics 3D — `orbit.graphics3d`

`graphics3d.cube(size)`, `mesh(vertices,edges,faces)`, `transform(mesh,rotation,position,scale)`, `project_point(point,width,height,camera_z,scale)`, `render_wireframe(canvas,mesh,color,camera_z,scale)`, and `render_solid(canvas,mesh,color,camera_z,scale,light_dir)`. The solid renderer supports flat-shaded triangle/polygon faces and painter sorting on the CPU. It is intended for low-poly indie scenes and simple effects, not a GPU shader pipeline.

## Flux Engine — `orbit.fluxengine`

`flux.scene(name,background)`, `flux.entity(scene,name,x,y,width,height,color,shape)`, `flux.velocity(entity,vx,vy)`, `flux.control(scene,player,speed,scheme)`, `flux.collectible(scene,name,x,y,size,color)`, `flux.goal(scene,count,message)`, `flux.label(scene,text,x,y,color,size)`, `flux.set_bounds(scene,enabled)`, `flux.update(scene,dt,gravity)`, `flux.render(scene,canvas)`, `flux.find`, `flux.remove`, `flux.collide`, and `flux.run(scene,width,height,title,fps)`. `flux.run` opens a native Tk game window and runs the update/input/render loop; it supports keyboard movement and collectible scoring. `flux.render` remains a separate single-frame off-screen renderer.

## Physics — `orbit.physics`

`physics.body(x,y,vx,vy,mass,radius)`, `apply_force`, `integrate`, `circle_overlap`, `aabb_overlap`, `distance`, `bounce`, `step`, `resolve_aabb`, and `resolve_circle`. This is a small deterministic 2D physics helper layer with basic positional correction and restitution. It is not a full rigid-body solver and does not implement joints, continuous collision detection, or 3D physics.

## Animation — `orbit.animation`

`animation.keyframe(time,value)`, `timeline(keyframes,time,easing)`, `lerp`, `ease_in`, `ease_out`, `ease_in_out`, and `ping_pong`.

## Audio — `orbit.audio`

`audio.tone(path,frequency,duration,volume,sample_rate,waveform)` writes mono 16-bit PCM WAV; waveform may be `sine`, `square`, `saw`, or `triangle`. `audio.info(path)` inspects WAV metadata. `audio.play(path)` uses `winsound` on Windows, `afplay` on macOS, or `aplay` on Linux when installed. It does not yet provide a multi-channel realtime mixer, audio device API, streaming, or spatial audio.

## Desktop Window — `orbit.window`, `orbit.ui`, `orbit.input`

`window.create(title,width,height)`, `window.label`, `window.run`, `window.close`, `window.set_title`, and `window.set_size`. `ui.button`, `ui.entry`, `ui.text_get`, `ui.text_set`, `ui.checkbox`, and `ui.checked` create Tk widgets. `input.bind_tk(window)`, `key_down`, `mouse_position`, and `mouse_down` provide a minimal event-state bridge. The Flux game window also updates this shared input state while a game is running. Requires Tkinter and a graphical desktop session; headless systems cannot display a window. No native cross-platform toolkit, accessibility audit, DPI/layout engine, or compositor integration is included.

## Debug — `orbit.debug`

`debug.assert_true(condition,message)`, `debug.type_of(value)`, `debug.inspect(value)`, `debug.profile_start()`, `debug.profile_end(start)`, and `debug.breakpoint_message(message)`.

## Office — `orbit.office`

Documents: `office.document(title,author)`, `paragraph`, `heading`, `table`, `export_html(document,path)`. Spreadsheets: `office.sheet(rows,columns)`, `cell_set(sheet,cell,value)`, `cell_get(sheet,cell)`, `export_csv(sheet,path)`. Supported formulas are basic arithmetic, cell references, and `SUM(A1:B4)` / `AVERAGE(A1:B4)`. Presentations: `office.presentation(title)`, `slide_add(deck,title,body)`, `export_presentation_html(deck,path)`. PDF: `office.export_pdf_text(title,text,path)` creates a minimal one-page PDF with text. This is not full Office file compatibility: DOCX, XLSX, PPTX import/export, advanced formatting, charts, comments, macros, and print pipelines are not implemented.
