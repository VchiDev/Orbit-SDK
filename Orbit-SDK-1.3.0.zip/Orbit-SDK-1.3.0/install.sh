#!/usr/bin/env sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
BIN="$ROOT/bin"
PYTHON=${PYTHON:-python3}
command -v "$PYTHON" >/dev/null 2>&1 || { echo "Python 3.10+ is required." >&2; exit 1; }
"$PYTHON" -c 'import sys; raise SystemExit(0 if sys.version_info >= (3,10) else 1)' || { echo "Python 3.10+ is required." >&2; exit 1; }
PROFILE="$HOME/.profile"
[ -f "$PROFILE" ] || : > "$PROFILE"
LINE="export PATH=\"$BIN:\$PATH\""
if ! grep -F "$BIN" "$PROFILE" >/dev/null 2>&1; then
  printf '\n# Orbit SDK 1.3.0\n%s\n' "$LINE" >> "$PROFILE"
  echo "Added $BIN to $PROFILE"
else
  echo "Orbit bin directory is already referenced in $PROFILE"
fi
chmod +x "$BIN/orbit" "$BIN/orbitc" "$BIN/orbitvm" "$BIN/orbitpkg" "$BIN/orbitnano" "$BIN/lux"
echo "Orbit SDK 1.3.0 installed. Open a new terminal or run: . ~/.profile"
