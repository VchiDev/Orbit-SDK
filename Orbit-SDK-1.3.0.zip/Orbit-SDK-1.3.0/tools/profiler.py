"""Wall-clock profiler for a compiled Orbit program."""
import time
from orbit_tool import read_beam, run_program

def profile(path):
    start=time.perf_counter(); run_program(read_beam(path)); return time.perf_counter()-start
