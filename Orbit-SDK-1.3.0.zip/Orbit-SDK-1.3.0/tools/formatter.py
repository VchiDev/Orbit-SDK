"""Conservative source formatter: whitespace cleanup without changing tokens."""
from pathlib import Path

def format_source(source):
    lines=[line.rstrip() for line in source.replace("\r\n","\n").replace("\r","\n").split("\n")]
    while lines and not lines[-1]: lines.pop()
    compact=[]
    for line in lines:
        if line.strip()=="" and (not compact or compact[-1]==""): continue
        compact.append(line)
    return "\n".join(compact)+"\n"

def format_file(path,check=False):
    p=Path(path); original=p.read_text(encoding="utf-8-sig"); formatted=format_source(original)
    if check: return original==formatted
    p.write_text(formatted,encoding="utf-8"); return True
