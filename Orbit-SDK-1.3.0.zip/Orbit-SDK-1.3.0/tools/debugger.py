"""Small bytecode inspection and trace runner."""
from orbit_tool import read_beam, run_program

def disassemble(path):
    p=read_beam(path)
    return [f"{i:04d} {ins['op']:<14} {ins.get('arg')!r}" for i,ins in enumerate(p['code'])]

def trace(path): return run_program(read_beam(path),verbose=True)
