"""Tk desktop host for Flux Engine's real-time 2D game loop."""
import time


def run_game(scene, width=640, height=360, title="Orbit Game", fps=60):
    try:
        import tkinter as tk
    except Exception as exc:
        raise RuntimeError(f"Flux Engine needs Tkinter for interactive windows: {exc}") from exc

    width, height = int(width), int(height)
    if not (160 <= width <= 2560 and 120 <= height <= 1600):
        raise ValueError("Flux window size must be between 160x120 and 2560x1600")
    fps = max(15, min(144, int(fps)))
    delay = max(1, round(1000 / fps))

    root = tk.Tk()
    root.title(str(title))
    root.resizable(False, False)
    view = tk.Canvas(root, width=width, height=height, bg=scene["background"],
                     highlightthickness=0, bd=0)
    view.pack()
    root.geometry(f"{width}x{height}")
    scene["width"], scene["height"] = width, height
    pressed = set()
    alive = {"value": True}
    previous = {"time": time.perf_counter()}

    def key_name(event):
        return str(event.keysym).lower()

    def on_press(event):
        pressed.add(key_name(event))
        try:
            from runtime.stdlib import input as orbit_input
            orbit_input._STATE["keys"].add(key_name(event))
        except Exception:
            pass
        if key_name(event) == "escape":
            alive["value"] = False
            root.destroy()

    def on_release(event):
        pressed.discard(key_name(event))
        try:
            from runtime.stdlib import input as orbit_input
            orbit_input._STATE["keys"].discard(key_name(event))
        except Exception:
            pass

    def on_mouse_move(event):
        try:
            from runtime.stdlib import input as orbit_input
            orbit_input._STATE.update(mouse_x=event.x, mouse_y=event.y)
        except Exception:
            pass

    def on_mouse_down(event):
        try:
            from runtime.stdlib import input as orbit_input
            orbit_input._STATE["mouse_buttons"].add(int(event.num))
        except Exception:
            pass

    def on_mouse_up(event):
        try:
            from runtime.stdlib import input as orbit_input
            orbit_input._STATE["mouse_buttons"].discard(int(event.num))
        except Exception:
            pass

    def on_close():
        alive["value"] = False
        root.destroy()

    root.bind_all("<KeyPress>", on_press)
    root.bind_all("<KeyRelease>", on_release)
    view.bind("<Motion>", on_mouse_move)
    view.bind("<ButtonPress>", on_mouse_down)
    view.bind("<ButtonRelease>", on_mouse_up)
    root.protocol("WM_DELETE_WINDOW", on_close)
    root.focus_force()

    def draw():
        view.delete("all")
        view.configure(bg=scene["background"])
        for e in scene["entities"]:
            if not e.get("visible", True):
                continue
            x, y = e["x"], e["y"]
            x2, y2 = x + e["width"], y + e["height"]
            shape = e.get("shape", "rect")
            if shape == "circle":
                view.create_oval(x, y, x2, y2, fill=e["color"], outline="")
            elif shape == "line":
                view.create_line(x, y, x2, y2, fill=e["color"], width=max(1, e.get("thickness", 2)))
            elif shape == "text":
                view.create_text(x, y, anchor="nw", text=e.get("text", e["name"]),
                                 fill=e["color"], font=("Segoe UI", max(8, int(e.get("size", 1) * 9))))
            else:
                view.create_rectangle(x, y, x2, y2, fill=e["color"], outline="")
        for item in scene.get("labels", []):
            view.create_text(item["x"], item["y"], anchor="nw", text=item["text"],
                             fill=item["color"], font=("Segoe UI", max(8, int(item["size"] * 9))))
        if scene.get("goal", 0) > 0:
            view.create_text(12, 10, anchor="nw", text=f"Crystals: {scene.get('score', 0)}/{scene['goal']}",
                             fill="#ffffff", font=("Segoe UI", 12, "bold"))
        if scene.get("goal", 0) > 0 and scene.get("score", 0) >= scene["goal"]:
            view.create_text(width / 2, 42, text=scene.get("message", "Goal complete!"),
                             fill="#fff4a3", font=("Segoe UI", 18, "bold"))

    def tick():
        if not alive["value"]:
            return
        now = time.perf_counter()
        dt = max(0.0, min(now - previous["time"], 0.05))
        previous["time"] = now

        for control in scene.get("controllers", []):
            player = control["entity"]
            speed = control["speed"]
            scheme = control.get("scheme", "arrows")
            left_keys = {"left", "a"} if scheme in ("arrows", "wasd", "arrows_wasd") else {"left"}
            right_keys = {"right", "d"} if scheme in ("arrows", "wasd", "arrows_wasd") else {"right"}
            up_keys = {"up", "w"} if scheme in ("arrows", "wasd", "arrows_wasd") else {"up"}
            down_keys = {"down", "s"} if scheme in ("arrows", "wasd", "arrows_wasd") else {"down"}
            vx = (-speed if pressed & left_keys else 0.0) + (speed if pressed & right_keys else 0.0)
            vy = (-speed if pressed & up_keys else 0.0) + (speed if pressed & down_keys else 0.0)
            if vx and vy:
                vx *= 0.70710678
                vy *= 0.70710678
            player["vx"], player["vy"] = vx, vy

        from .core import update, collide
        update(scene, dt, scene.get("gravity", 0.0))
        player = scene.get("player")
        if player and scene.get("keep_player_in_bounds", True):
            player["x"] = max(0, min(width - player["width"], player["x"]))
            player["y"] = max(0, min(height - player["height"], player["y"]))
        if player:
            collected = [e for e in scene["entities"] if e.get("kind") == "collectible" and collide(player, e)]
            for item in collected:
                scene["entities"].remove(item)
                scene["score"] = int(scene.get("score", 0)) + 1
        draw()
        if alive["value"]:
            root.after(delay, tick)

    draw()
    root.after(delay, tick)
    root.mainloop()
    try:
        from runtime.stdlib import input as orbit_input
        orbit_input._STATE["keys"].clear()
        orbit_input._STATE["mouse_buttons"].clear()
    except Exception:
        pass
    return {"closed": True, "score": int(scene.get("score", 0)), "time": float(scene.get("time", 0.0))}
