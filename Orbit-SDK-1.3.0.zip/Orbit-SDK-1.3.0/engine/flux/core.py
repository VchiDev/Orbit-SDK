"""Flux Engine 2D scene model, simulation helpers, and interactive game entry point."""
from runtime.stdlib import graphics


def scene(name="Scene", background="#202633"):
    return {
        "name": str(name), "background": background, "entities": [], "labels": [],
        "time": 0.0, "score": 0, "goal": 0, "message": "", "controllers": [],
        "width": 640, "height": 360, "gravity": 0.0,
    }


def entity(scene, name="Entity", x=0, y=0, width=32, height=32, color="#ffffff", shape="rect"):
    e = {
        "name": str(name), "x": float(x), "y": float(y), "width": float(width),
        "height": float(height), "color": color, "shape": str(shape), "vx": 0.0,
        "vy": 0.0, "visible": True, "rotation": 0.0, "kind": "entity",
    }
    scene["entities"].append(e)
    return e


def velocity(e, vx, vy):
    e["vx"], e["vy"] = float(vx), float(vy)
    return e


def control(scene, player, speed=220, scheme="arrows"):
    """Attach built-in keyboard movement. Arrows/WASD are supported by the window host."""
    if player not in scene["entities"]:
        raise ValueError("Controlled entity must belong to this scene")
    control_data = {"entity": player, "speed": max(1.0, float(speed)), "scheme": str(scheme)}
    scene["controllers"] = [c for c in scene["controllers"] if c["entity"] is not player]
    scene["controllers"].append(control_data)
    scene["player"] = player
    return player


def collectible(scene, name, x, y, size=22, color="#6ee7ff"):
    item = entity(scene, name, x, y, size, size, color, "circle")
    item["kind"] = "collectible"
    return item


def label(scene, text, x=16, y=16, color="#ffffff", size=2):
    item = {"text": str(text), "x": float(x), "y": float(y), "color": color, "size": int(size)}
    scene["labels"].append(item)
    return item


def goal(scene, count, message="Goal complete!"):
    scene["goal"] = max(0, int(count))
    scene["message"] = str(message)
    return scene


def set_bounds(scene, enabled=True):
    scene["keep_player_in_bounds"] = bool(enabled)
    return scene


def update(scene, dt, gravity=0):
    dt = max(0.0, min(float(dt), .25))
    scene["time"] += dt
    for e in scene["entities"]:
        if e["kind"] == "collectible":
            continue
        e["vy"] += float(gravity) * dt
        e["x"] += e["vx"] * dt
        e["y"] += e["vy"] * dt
    return scene


def render(scene, canvas):
    graphics.clear(canvas, scene["background"])
    for e in scene["entities"]:
        if not e["visible"]:
            continue
        x, y, w, h = e["x"], e["y"], e["width"], e["height"]
        if e["shape"] == "circle":
            graphics.circle(canvas, x + w / 2, y + h / 2, min(w, h) / 2, e["color"])
        elif e["shape"] == "text":
            graphics.text(canvas, x, y, e.get("text", e["name"]), e["color"], e.get("size", 1))
        else:
            graphics.rect(canvas, x, y, w, h, e["color"])
    for item in scene["labels"]:
        graphics.text(canvas, item["x"], item["y"], item["text"], item["color"], item["size"])
    return canvas


def find(scene, name):
    return next((e for e in scene["entities"] if e["name"] == name), None)


def remove(scene, name):
    before = len(scene["entities"])
    scene["entities"][:] = [e for e in scene["entities"] if e["name"] != name]
    return len(scene["entities"]) != before


def collide(a, b):
    return not (
        a["x"] + a["width"] < b["x"] or b["x"] + b["width"] < a["x"]
        or a["y"] + a["height"] < b["y"] or b["y"] + b["height"] < a["y"]
    )


def run(scene, width=640, height=360, title=None, fps=60):
    """Open a native window and run the scene until the player closes it.

    This uses Tkinter from the Python standard library. It requires a desktop
    session; headless systems should use flux.render + graphics.save_png.
    """
    from .window import run_game
    return run_game(scene, width, height, title or scene["name"], fps)
