"""Lazy host-function registry shared by the full SDK and compact Orbit Nano."""
from __future__ import annotations
import importlib
import math as _math


def _console_log(value=None):
    from runtime.stdlib.console import log
    return log(value)


BUILTINS = {
    "signal": _console_log,
    "print": _console_log,
    "len": len,
    "str": str,
    "int": int,
    "float": float,
    "bool": bool,
    "abs": abs,
    "min": min,
    "max": max,
    "round": round,
    "range": lambda *a: list(range(*map(int, a))),
    "type": lambda value: type(value).__name__,
}

# namespace.member -> (importable module, implementation attribute)
_REGISTRY = {}

def _register(namespace, module, names):
    for name in names:
        _REGISTRY[f"{namespace}.{name}"] = (module, name)

_register("console", "runtime.stdlib.console", ["write", "log", "read_line", "clear", "color"])
_register("math", "math", ["sin", "cos", "tan", "asin", "acos", "atan", "atan2", "sqrt", "floor", "ceil", "log", "log10", "exp"])
_register("math", "runtime.stdlib.mathlib", ["vec2", "vec3", "dot", "length", "normalize", "distance", "lerp", "clamp", "map_range", "radians", "degrees", "random", "random_int", "pi", "tau", "e", "hypot", "is_finite"])
_register("text", "runtime.stdlib.text", ["upper", "lower", "trim", "split", "join", "replace", "contains", "starts_with", "ends_with", "substring", "format", "normalize_unicode", "matches", "regex_find_all", "codepoints", "from_codepoints"])
_register("data", "runtime.stdlib.data", ["json_parse", "json_stringify", "csv_parse", "csv_stringify", "base64_encode", "base64_decode", "keys", "values", "has", "merge", "sort", "unique", "push", "pop", "contains"])
_register("files", "runtime.stdlib.files", ["exists", "is_file", "is_dir", "read_text", "write_text", "read_bytes", "write_bytes", "append_text", "mkdir", "list_dir", "copy", "move", "remove", "join", "name", "extension", "sha256"])
_register("time", "runtime.stdlib.timelib", ["now", "unix", "sleep", "timestamp", "date_string", "measure_start", "elapsed", "format_timestamp"])
_register("system", "runtime.stdlib.system", ["os_name", "os_version", "architecture", "python_version", "cwd", "env", "set_env", "args", "home", "newline"])
_register("security", "runtime.stdlib.security", ["sha256", "sha512", "hmac_sha256", "secure_token", "random_bytes", "constant_time_equal", "base64_encode", "base64_decode"])
_register("network", "runtime.stdlib.network", ["get", "post", "head", "download"])
_register("graphics", "runtime.stdlib.graphics", ["canvas", "pixel", "clear", "rect", "line", "circle", "polygon", "text", "save_png", "pixel_get"])
_register("graphics3d", "runtime.stdlib.graphics3d", ["mesh", "cube", "transform", "render_wireframe", "render_solid", "project_point"])
_register("physics", "runtime.stdlib.physics", ["body", "apply_force", "integrate", "circle_overlap", "aabb_overlap", "distance", "bounce", "step", "resolve_aabb", "resolve_circle"])
_register("animation", "runtime.stdlib.animation", ["lerp", "ease_in", "ease_out", "ease_in_out", "keyframe", "timeline", "ping_pong"])
_register("audio", "runtime.stdlib.audio", ["tone", "info", "play"])
_register("window", "runtime.stdlib.window", ["create", "label", "run", "close", "set_title", "set_size"])
_register("ui", "runtime.stdlib.ui", ["button", "entry", "text_get", "text_set", "checkbox", "checked"])
_register("input", "runtime.stdlib.input", ["key_down", "mouse_position", "mouse_down", "bind_tk"])
_register("debug", "runtime.stdlib.debug", ["assert_true", "type_of", "inspect", "profile_start", "profile_end", "breakpoint_message"])
_register("database", "runtime.stdlib.database", ["open_database", "execute", "query", "close", "table_exists"])
_register("flux", "engine.flux.core", ["scene", "entity", "velocity", "control", "collectible", "label", "goal", "set_bounds", "update", "render", "find", "remove", "collide", "run"])
_register("office", "office.core", ["document", "paragraph", "heading", "table", "export_html", "sheet", "cell_set", "cell_get", "export_csv", "presentation", "slide_add", "export_presentation_html", "export_pdf_text"])
_register("desktop", "runtime.stdlib.window", ["create", "label", "run", "close", "set_title", "set_size"])

_CONSTANTS = {"math.pi": _math.pi, "math.tau": _math.tau, "math.e": _math.e}


def resolve_library_function(name):
    if name in _CONSTANTS:
        return lambda: _CONSTANTS[name]
    spec = _REGISTRY.get(name)
    if spec is None:
        return None
    module_name, attr = spec
    module = importlib.import_module(module_name)
    return getattr(module, attr, None)


class LazyLibraryRegistry(dict):
    """Dict-like .get() so the VM can resolve only libraries an app actually uses."""
    def get(self, key, default=None):
        fn = resolve_library_function(key)
        return default if fn is None else fn

    def __contains__(self, key):
        return key in _REGISTRY or key in _CONSTANTS

    def __iter__(self):
        return iter(set(_REGISTRY) | set(_CONSTANTS))

    def __len__(self):
        return len(set(_REGISTRY) | set(_CONSTANTS))


LIBRARY_FUNCTIONS = LazyLibraryRegistry()
