$ErrorActionPreference = 'Stop'
$Root = (Resolve-Path $PSScriptRoot).Path
$Bin = Join-Path $Root 'bin'
$Python = Get-Command python -ErrorAction SilentlyContinue
if (-not $Python) { throw 'Python 3.10+ is required. Install Python and enable Add Python to PATH.' }
$Version = & python --version 2>&1
if ($LASTEXITCODE -ne 0) { throw 'Python could not be started.' }
$IsSupported = (& python -c "import sys; print(sys.version_info >= (3,10))").Trim()
if ($IsSupported -ne 'True') { throw "Python 3.10+ required. Found: $Version" }
$UserPath = [Environment]::GetEnvironmentVariable('Path','User')
$Parts = @($UserPath -split ';' | Where-Object { $_ -and $_.Trim() })
$Normalized = @($Parts | ForEach-Object { $_.Trim().TrimEnd('\') })
if ($Normalized -notcontains $Bin.TrimEnd('\')) {
  [Environment]::SetEnvironmentVariable('Path', (($Parts + $Bin) -join ';'), 'User')
  Write-Host "Added $Bin to user PATH."
} else { Write-Host 'Orbit is already on PATH.' }
Write-Host "Orbit SDK 1.3.0 installed. Python: $Version"
Write-Host 'Open a NEW PowerShell window, then run: orbit --version; orbitc --version; orbitvm --version; orbitpkg --version; orbitnano --version; lux list'
