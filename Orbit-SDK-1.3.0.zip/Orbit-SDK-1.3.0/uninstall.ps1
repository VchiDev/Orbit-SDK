$ErrorActionPreference = 'Stop'
$Bin = (Resolve-Path (Join-Path $PSScriptRoot 'bin')).Path
$Parts = @([Environment]::GetEnvironmentVariable('Path','User') -split ';' | Where-Object { $_ -and $_.Trim() })
$Keep = @($Parts | Where-Object { $_.Trim().TrimEnd('\') -ne $Bin.TrimEnd('\') })
[Environment]::SetEnvironmentVariable('Path', ($Keep -join ';'), 'User')
Write-Host 'Removed Orbit bin from user PATH. The SDK folder was not deleted.'
