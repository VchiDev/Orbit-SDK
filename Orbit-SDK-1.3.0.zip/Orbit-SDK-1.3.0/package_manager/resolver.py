"""Lux manifest resolver for SDK and application-local libraries."""
from pathlib import Path, PurePosixPath
import re
from orbit_tool import LIBS, lux_parse, OrbitError

def resolve_lux(spec,project_dir=None):
    value=str(spec)
    if value.startswith("orbit."):
        if not value.endswith(".lux"): value += ".lux"
        if not re.fullmatch(r"orbit\.[A-Za-z_][A-Za-z0-9_.]*\.lux",value): raise OrbitError("Invalid built-in Lux name")
        path=(LIBS/value).resolve()
        if not path.is_relative_to(LIBS.resolve()): raise OrbitError("Built-in Lux path escapes SDK")
    elif value.startswith("lib/") and project_dir is not None:
        rel=PurePosixPath(value)
        if rel.is_absolute() or ".." in rel.parts or "\\" in value: raise OrbitError("Unsafe app-local Lux path")
        root=Path(project_dir).resolve(); path=(root/Path(*rel.parts)).resolve()
        if not path.is_relative_to(root): raise OrbitError("App-local Lux path escapes project")
    else: raise OrbitError(f"Unknown Lux library specifier: {value}")
    return path,lux_parse(path)
