"""Project package entry points."""
import json, zipfile
from pathlib import Path, PurePosixPath
from orbit_tool import compile_source, FORMAT, OrbitError
from .manifest import validate_manifest

def build_project(project=".",output=None):
    root=Path(project).resolve(); manifest=validate_manifest(json.loads((root/"orbit.json").read_text(encoding="utf-8")),root); entry=manifest.get("entry","src/main.orb")
    pure=PurePosixPath(entry)
    if pure.is_absolute() or ".." in pure.parts or "\\" in entry: raise OrbitError("Unsafe project entry")
    src=(root/entry).resolve()
    if not src.is_relative_to(root) or not src.is_file(): raise OrbitError("Project entry is missing or outside project")
    program=compile_source(src.read_text(encoding="utf-8-sig")); out=Path(output).resolve() if output else root/(manifest.get("name","app")+".orbit")
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("orbit.json",json.dumps(manifest,indent=2)); z.writestr("main.beam",json.dumps(program,indent=2))
        for f in root.rglob("*"):
            if f.is_file() and f.resolve()!=out and f.resolve()!=src and f.name!="orbit.json" and f.suffix!=".orbit" and not any(p in (".git","__pycache__") for p in f.relative_to(root).parts): z.write(f,f.relative_to(root).as_posix())
    return out
