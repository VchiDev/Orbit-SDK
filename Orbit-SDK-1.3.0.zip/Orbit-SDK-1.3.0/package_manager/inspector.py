"""Safe archive inspection."""
from pathlib import Path, PurePosixPath
import zipfile, json
from orbit_tool import OrbitError, FORMAT

def inspect_package(path):
    with zipfile.ZipFile(path) as z:
        names=z.namelist()
        for name in names:
            p=PurePosixPath(name)
            if p.is_absolute() or ".." in p.parts or "\\" in name: raise OrbitError("Unsafe archive member")
        if "orbit.json" not in names or "main.beam" not in names: raise OrbitError("Invalid Orbit package")
        manifest=json.loads(z.read("orbit.json")); program=json.loads(z.read("main.beam"))
        if program.get("format")!=FORMAT: raise OrbitError("Incompatible BEAM version")
        return {"manifest":manifest,"files":names,"instructions":len(program.get("code",[])),"functions":list(program.get("functions",{}))}
