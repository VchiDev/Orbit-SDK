"""Orbit project manifest validation."""
import json, re
from pathlib import Path, PurePosixPath
from orbit_tool import OrbitError

def validate_manifest(manifest, project_dir="."):
    if not isinstance(manifest,dict): raise OrbitError("orbit.json must contain a JSON object")
    name=manifest.get("name"); version=manifest.get("version"); entry=manifest.get("entry","src/main.orb")
    if not isinstance(name,str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}",name): raise OrbitError("Project name must be 1-64 safe filename characters")
    if not isinstance(version,str) or not re.fullmatch(r"\d+\.\d+\.\d+",version): raise OrbitError("Project version must use semantic x.y.z form")
    if not isinstance(entry,str): raise OrbitError("Project entry must be a relative path string")
    p=PurePosixPath(entry)
    if p.is_absolute() or ".." in p.parts or "\\" in entry: raise OrbitError("Project entry path is unsafe")
    root=Path(project_dir).resolve(); source=(root/Path(*p.parts)).resolve()
    if not source.is_relative_to(root): raise OrbitError("Project entry escapes the project directory")
    if not source.is_file(): raise OrbitError(f"Project entry file does not exist: {entry}")
    return {**manifest,"entry":entry}

def load_manifest(project_dir="."):
    path=Path(project_dir).resolve()/"orbit.json"
    if not path.is_file(): raise OrbitError(f"Missing project manifest: {path}")
    return validate_manifest(json.loads(path.read_text(encoding="utf-8")),project_dir)
