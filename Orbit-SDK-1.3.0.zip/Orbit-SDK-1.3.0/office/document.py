from office.core import document, paragraph, heading, table, export_html
__all__=["document","paragraph","heading","table","export_html"]
