"""Lightweight office document model and exporters using only Python's standard library."""
import csv, io, html, re, ast, operator

def document(title="Untitled",author=""):
    return {"type":"document","title":str(title),"author":str(author),"blocks":[]}
def paragraph(doc,text): doc["blocks"].append({"type":"paragraph","text":str(text)}); return doc
def heading(doc,text,level=1): doc["blocks"].append({"type":"heading","level":max(1,min(6,int(level))),"text":str(text)}); return doc
def table(doc,rows): doc["blocks"].append({"type":"table","rows":rows}); return doc
def export_html(doc,path):
    from pathlib import Path
    pieces=["<!doctype html><html><head><meta charset='utf-8'><title>"+html.escape(doc["title"])+"</title><style>body{font:16px/1.6 system-ui;max-width:850px;margin:40px auto;padding:0 20px}table{border-collapse:collapse}td,th{border:1px solid #999;padding:8px}</style></head><body>"]
    for b in doc["blocks"]:
        if b["type"]=="paragraph": pieces.append("<p>"+html.escape(b["text"])+"</p>")
        elif b["type"]=="heading": pieces.append(f"<h{b['level']}>"+html.escape(b["text"])+f"</h{b['level']}>")
        elif b["type"]=="table": pieces.append("<table>"+"".join("<tr>"+"".join("<td>"+html.escape(str(c))+"</td>" for c in row)+"</tr>" for row in b["rows"])+"</table>")
    pieces.append("</body></html>"); p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_text("\n".join(pieces),encoding="utf-8"); return str(p)
def sheet(rows=20,columns=8): return {"type":"sheet","rows":max(1,int(rows)),"columns":max(1,int(columns)),"cells":{}}
def cell_set(s,cell,value): s["cells"][str(cell).upper()]=value; return value
def _col_index(label):
    n=0
    for ch in label: n=n*26+ord(ch.upper())-64
    return n-1
def _cell(s,ref,seen=None):
    ref=str(ref).upper(); seen=seen or set()
    if ref in seen: raise ValueError("Circular spreadsheet formula")
    value=s["cells"].get(ref,"")
    if isinstance(value,str) and value.startswith("="):
        expr=value[1:].strip(); seen.add(ref)
        # Evaluate a safe arithmetic subset and SUM/AVERAGE over explicit ranges.
        m=re.fullmatch(r"(SUM|AVERAGE)\(([A-Z]+\d+):([A-Z]+\d+)\)",expr,re.I)
        if m:
            a,b=m.group(2),m.group(3); ma=re.fullmatch(r"([A-Z]+)(\d+)",a); mb=re.fullmatch(r"([A-Z]+)(\d+)",b)
            vals=[]
            for row in range(int(ma.group(2)),int(mb.group(2))+1):
                for col in range(_col_index(ma.group(1)),_col_index(mb.group(1))+1):
                    colname=""; x=col+1
                    while x: x,r=divmod(x-1,26); colname=chr(65+r)+colname
                    v=_cell(s,f"{colname}{row}",seen.copy()); vals.append(float(v) if v not in ("",None) else 0)
            return sum(vals) if m.group(1).upper()=="SUM" else (sum(vals)/len(vals) if vals else 0)
        tree=ast.parse(expr,mode="eval")
        ops={ast.Add:operator.add,ast.Sub:operator.sub,ast.Mult:operator.mul,ast.Div:operator.truediv,ast.Pow:operator.pow,ast.USub:operator.neg,ast.UAdd:operator.pos}
        def calc(n):
            if isinstance(n,ast.Expression): return calc(n.body)
            if isinstance(n,ast.Constant) and isinstance(n.value,(int,float)): return n.value
            if isinstance(n,ast.BinOp) and type(n.op) in ops: return ops[type(n.op)](calc(n.left),calc(n.right))
            if isinstance(n,ast.UnaryOp) and type(n.op) in ops: return ops[type(n.op)](calc(n.operand))
            if isinstance(n,ast.Name) and re.fullmatch(r"[A-Z]+[0-9]+",n.id): return float(_cell(s,n.id,seen.copy()) or 0)
            raise ValueError("Formula supports arithmetic and cell references, or SUM/AVERAGE(range)")
        return calc(tree)
    return value
def cell_get(s,ref): return _cell(s,ref)
def export_csv(s,path):
    from pathlib import Path
    refs=list(s["cells"]); max_row=max([int(re.search(r"\d+",r).group()) for r in refs] or [1]); max_col=max([_col_index(re.match(r"[A-Z]+",r).group()) for r in refs] or [0]); rows=[]
    for r in range(1,max_row+1):
        row=[]
        for c in range(max_col+1):
            name=""; n=c+1
            while n: n,rem=divmod(n-1,26); name=chr(65+rem)+name
            row.append(cell_get(s,f"{name}{r}"))
        rows.append(row)
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    with p.open("w",newline="",encoding="utf-8-sig") as f: csv.writer(f).writerows(rows)
    return str(p)
def presentation(title="Presentation"): return {"type":"presentation","title":str(title),"slides":[]}
def slide_add(deck,title,body=""):
    deck["slides"].append({"title":str(title),"body":str(body)}); return len(deck["slides"])
def export_presentation_html(deck,path):
    from pathlib import Path
    slides="".join("<section><h1>"+html.escape(x["title"])+"</h1><p>"+html.escape(x["body"])+"</p></section>" for x in deck["slides"])
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_text("<!doctype html><meta charset='utf-8'><title>"+html.escape(deck["title"])+"</title><style>body{font:24px system-ui;background:#101827;color:white}section{min-height:90vh;padding:5vw;box-sizing:border-box;border-bottom:1px solid #456}</style>"+slides,encoding="utf-8"); return str(p)
def export_pdf_text(title,text,path):
    """Write a minimal valid one-page PDF containing ASCII-safe text."""
    from pathlib import Path
    def esc(s): return str(s).encode("latin-1","replace").decode("latin-1").replace("\\","\\\\").replace("(","\\(").replace(")","\\)")
    lines=str(text).splitlines()[:48]; stream="BT /F1 12 Tf 50 790 Td ("+esc(title)+") Tj 0 -24 Td "+" ".join("("+esc(x[:110])+") Tj 0 -16 Td" for x in lines)+" ET"
    objs=["<< /Type /Catalog /Pages 2 0 R >>","<< /Type /Pages /Kids [3 0 R] /Count 1 >>","<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R >> >> /Contents 5 0 R >>","<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",f"<< /Length {len(stream.encode('latin-1'))} >>\nstream\n{stream}\nendstream"]
    data=bytearray(b"%PDF-1.4\n"); offsets=[0]
    for i,obj in enumerate(objs,1): offsets.append(len(data)); data.extend(f"{i} 0 obj\n{obj}\nendobj\n".encode("latin-1"))
    xref=len(data); data.extend(f"xref\n0 {len(offsets)}\n0000000000 65535 f \n".encode())
    for off in offsets[1:]: data.extend(f"{off:010d} 00000 n \n".encode())
    data.extend(f"trailer << /Size {len(offsets)} /Root 1 0 R >>\nstartxref\n{xref}\n%%EOF\n".encode())
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data); return str(p)
