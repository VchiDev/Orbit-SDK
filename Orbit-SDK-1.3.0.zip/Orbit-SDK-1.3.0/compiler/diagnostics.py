"""Compiler/runtime diagnostic exception."""
from orbit_tool import OrbitError
__all__ = ["OrbitError"]
