import sys, unittest, tempfile, json, zipfile, wave, math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
import orbit_tool as o
from orbit_stdlib import LIBRARY_FUNCTIONS
from runtime.stdlib import graphics, graphics3d, physics, audio, data
from office import core as office
from engine.flux import core as flux

class OrbitCompilerTests(unittest.TestCase):
    def compile_run(self,src): return o.compile_source(src)
    def execute(self,src):
        output=[]; o.run_program(self.compile_run(src),output=output.append,cwd=ROOT); return output
    def test_arithmetic_and_precedence(self):
        self.assertEqual(self.execute('signal(2 + 3 * 4)'),[14])
    def test_user_functions_and_return(self):
        src='fn square(x) { return x * x }\nsignal(square(9))'
        self.assertEqual(self.execute(src),[81])
    def test_function_can_read_global(self):
        self.assertEqual(self.execute('var x=7\nfn f() { return x+1 }\nsignal(f())'),[8])
    def test_recursive_function(self):
        src='fn factorial(n) { if n <= 1 { return 1 } else { return n * factorial(n-1) } }\nsignal(factorial(6))'
        self.assertEqual(self.execute(src),[720])
    def test_for_and_while(self):
        src='var s=0\nfor n in range(1,5) { s += n }\nvar i=0\nwhile i<2 { s+=i\ni+=1 }\nsignal(s)'
        self.assertEqual(self.execute(src),[11])
    def test_break_continue_and_short_circuit(self):
        src='var s=0\nfor n in range(0,10) { if n == 2 { continue } if n == 6 { break } s += n }\nsignal(s)\nsignal(false and (1 / 0))\nsignal(true or (1 / 0))'
        self.assertEqual(self.execute(src),[13,False,True])
    def test_index_and_member_assignment(self):
        src='var values=[1,2]\nvalues[1] += 5\nvar item={name:"Orbit"}\nitem.name = "Nano"\nsignal(values[1])\nsignal(item.name)'
        self.assertEqual(self.execute(src),[7,"Nano"])
    def test_lists_maps_and_indexing(self):
        src='var p={name:"Orbit",items:[3,4]}\nsignal(p["name"])\nsignal(p["items"][1])'
        self.assertEqual(self.execute(src),["Orbit",4])
    def test_constants_and_undefined(self):
        with self.assertRaises(o.OrbitError): o.run_program(self.compile_run('const x=1\nx=2'))
        with self.assertRaises(o.OrbitError): o.run_program(self.compile_run('signal(missing)'))
    def test_infinite_loop_guard(self):
        with self.assertRaisesRegex(o.OrbitError,"step limit"):
            o.run_program(self.compile_run('while true {}'),max_steps=30)
    def test_beam_roundtrip(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'x.beam'; o.write_beam(self.compile_run('signal("ok")'),p)
            self.assertEqual(o.read_beam(p)['format'],o.FORMAT)
    def test_memory_code(self):
        for n in (0,1,15,16,255): self.assertEqual(o.decode_number(o.encode_number(n)),n)
        self.assertEqual(o.decode_text(o.encode_text("Orbit 123")),"Orbit 123")
        self.assertEqual(o.encode_address(65535),"HHHH")

class StandardLibraryTests(unittest.TestCase):
    def test_lux_manifests_have_implementations(self):
        paths=list(o.LIBS.glob('*.lux'))
        self.assertEqual(len(paths),22)
        self.assertTrue(all(o.lux_parse(p)['VERSION']==o.VERSION for p in paths))
        self.assertTrue(all(o.lux_parse(p)['STATUS'] not in ('API-CONTRACT',) for p in paths))
        prefixes={name.split('.',1)[1] for name in (o.lux_parse(p)['NAME'] for p in paths)}
        for prefix in prefixes:
            runtime_prefix={"fluxengine":"flux","desktop":"window","graphics3d":"graphics3d"}.get(prefix,prefix)
            self.assertTrue(any(name.startswith(runtime_prefix+".") for name in LIBRARY_FUNCTIONS),f"Missing runtime namespace for {prefix}")
    def test_namespaced_math_text_and_json(self):
        src='lux.loadLib(orbit.math.lux)\nlux.loadLib(orbit.text.lux)\nsignal(math.sqrt(81))\nsignal(text.upper("orbit"))\nsignal(math.pi())'
        out=[]; o.run_program(o.compile_source(src),output=out.append,cwd=ROOT)
        self.assertEqual(out,[9.0,"ORBIT",math.pi])
    def test_filesystem_api(self):
        with tempfile.TemporaryDirectory() as d:
            out=[]; source=f'lux.loadLib(orbit.files.lux)\nfiles.write_text({json.dumps(str(Path(d)/"hello.txt"))}, "Orbit file")\nsignal(files.read_text({json.dumps(str(Path(d)/"hello.txt"))}))'
            o.run_program(o.compile_source(source),output=out.append,cwd=ROOT)
            self.assertEqual(out,["Orbit file"])
    def test_relative_paths_use_project_working_directory(self):
        import os
        old=os.getcwd()
        with tempfile.TemporaryDirectory() as d:
            src='lux.loadLib(orbit.files.lux)\nfiles.write_text("relative.txt", "rooted")'
            o.run_program(o.compile_source(src),cwd=d)
            self.assertEqual((Path(d)/"relative.txt").read_text(),"rooted")
        self.assertEqual(os.getcwd(),old)
    def test_application_lux_path_traversal_is_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            src='lux.loadLib("lib/../../outside.lux")'
            with self.assertRaises(o.OrbitError): o.run_program(o.compile_source(src),cwd=d)
    def test_application_local_lux_library_loads(self):
        with tempfile.TemporaryDirectory() as d:
            lib=Path(d)/"lib"/"custom.lux"; lib.parent.mkdir()
            lib.write_text("LUX-LIBRARY 01\nNAME sample.custom\nVERSION 1.0.0\nSTATUS IMPLEMENTED\nDESCRIPTION test\nMODULE core\n")
            o.run_program(o.compile_source('lux.loadLib("lib/custom.lux")'),cwd=d)
    def test_custom_lux_source_exports_functions(self):
        with tempfile.TemporaryDirectory() as d:
            lib=Path(d)/"lib"; lib.mkdir()
            (lib/"mathkit.lux").write_text("LUX-LIBRARY 01\nNAME sample.mathkit\nVERSION 1.0.0\nSTATUS IMPLEMENTED\nDESCRIPTION custom math\nNAMESPACE mathkit\nSOURCE mathkit.orb\nMODULE helpers\nEXPORT square\nEXPORT sum_squares\n")
            (lib/"mathkit.orb").write_text("fn square(x) { return x*x }\nfn sum_squares(a,b) { return square(a)+square(b) }\n")
            out=[]
            o.run_program(o.compile_source('lux.loadLib("lib/mathkit.lux")\nsignal(mathkit.square(5))\nsignal(mathkit.sum_squares(3,4))'),cwd=d,output=out.append)
            self.assertEqual(out,[25,25])
    def test_software_graphics_png(self):
        with tempfile.TemporaryDirectory() as d:
            c=graphics.canvas(64,48,"#102030"); graphics.rect(c,4,4,20,10,"#ff0000"); graphics.circle(c,40,20,8,"#00ff00")
            path=graphics.save_png(c,Path(d)/'frame.png')
            self.assertEqual(Path(path).read_bytes()[:8],b'\x89PNG\r\n\x1a\n')
            self.assertEqual(graphics.pixel_get(c,5,5),[255,0,0,255])
    def test_3d_wireframe(self):
        c=graphics.canvas(100,100,"#000000"); cube=graphics3d.transform(graphics3d.cube(),[.2,.4,.1])
        graphics3d.render_wireframe(c,cube,"#ffffff")
        self.assertTrue(any(c['pixels']))
    def test_3d_solid_renderer(self):
        c=graphics.canvas(120,100,"#000000")
        cube=graphics3d.transform(graphics3d.cube(1.8),[.3,.5,.1],[0,0,0])
        graphics3d.render_solid(c,cube,"#60b8ff",5,110)
        self.assertTrue(any(c['pixels']))
    def test_physics_integration(self):
        b=physics.body(); physics.integrate(b,1,0,10)
        self.assertAlmostEqual(b['vy'],10); self.assertAlmostEqual(b['y'],10)
    def test_physics_collision_resolution(self):
        a={"x":0.0,"y":0.0,"w":10.0,"h":10.0,"vx":1.0,"vy":0.0}
        b={"x":8.0,"y":0.0,"w":10.0,"h":10.0,"vx":-1.0,"vy":0.0}
        self.assertTrue(physics.resolve_aabb(a,b,0.5))
        self.assertLessEqual(a["x"]+a["w"],b["x"]+1e-9)
        self.assertLess(a["vx"],0)
        self.assertGreater(b["vx"],0)
        c=physics.body(0,0,1,0,1,5); d=physics.body(8,0,-1,0,1,5)
        self.assertTrue(physics.resolve_circle(c,d,0.5))
        self.assertGreaterEqual(math.dist([c["x"],c["y"]],[d["x"],d["y"]]),10-1e-6)
    def test_audio_wav_generation(self):
        with tempfile.TemporaryDirectory() as d:
            result=audio.tone(Path(d)/'tone.wav',440,.05)
            self.assertGreater(result['samples'],0)
            with wave.open(str(Path(d)/'tone.wav')) as w: self.assertEqual(w.getframerate(),44100)
    def test_spreadsheet_formula(self):
        s=office.sheet(); office.cell_set(s,'A1',12); office.cell_set(s,'A2',30); office.cell_set(s,'A3','=SUM(A1:A2)')
        self.assertEqual(office.cell_get(s,'A3'),42)
    def test_pdf_export(self):
        with tempfile.TemporaryDirectory() as d:
            p=office.export_pdf_text('Orbit','A small PDF',Path(d)/'report.pdf')
            self.assertTrue(Path(p).read_bytes().startswith(b'%PDF-1.4'))
    def test_sqlite(self):
        from runtime.stdlib import database
        db=database.open_database(); database.execute(db,'create table people(name text)'); database.execute(db,'insert into people values (?)',['Orbit'])
        self.assertEqual(database.query(db,'select name from people')[0]['name'],'Orbit'); database.close(db)
    def test_flux_scene(self):
        s=flux.scene('test'); e=flux.entity(s,'hero',1,2,10,10,'#ffffff'); flux.velocity(e,2,0); flux.update(s,1)
        self.assertEqual(e['x'],1.5)
        c=graphics.canvas(32,32); flux.render(s,c); self.assertTrue(any(c['pixels']))
    def test_flux_game_helpers(self):
        s=flux.scene('playable')
        p=flux.entity(s,'player',0,0,20,20,'#ffffff')
        flux.control(s,p,200,'arrows_wasd')
        gem=flux.collectible(s,'gem',40,40)
        flux.goal(s,1,'won')
        self.assertEqual(s['controllers'][0]['entity'],p)
        self.assertEqual(gem['kind'],'collectible')
        self.assertEqual(s['goal'],1)

class PackagingTests(unittest.TestCase):
    def test_package_build_inspect_and_run(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'project'; (root/'src').mkdir(parents=True)
            (root/'orbit.json').write_text(json.dumps({'name':'test-app','version':'1.0.0','entry':'src/main.orb'}))
            (root/'src'/'main.orb').write_text('signal("PACKAGE OK")')
            self.assertEqual(o.cli_pkg(['build',str(root)]),0)
            package=root/'test-app.orbit'
            self.assertTrue(package.is_file())
            self.assertEqual(o.cli_pkg(['inspect',str(package)]),0)
            self.assertEqual(o.cli_pkg(['run',str(package)]),0)
    def test_loadnano_embeds_runtime_metadata_and_assets(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'project'; (root/'src').mkdir(parents=True); (root/'assets'/'sprites').mkdir(parents=True)
            (root/'orbit.json').write_text(json.dumps({'name':'embedded-demo','version':'1.0.0','entry':'src/main.orb'}))
            (root/'src'/'main.orb').write_text('orbit.LoadNano()\nlux.loadLib(orbit.console.lux)\nsignal("EMBEDDED NANO OK")')
            (root/'assets'/'sprites'/'player.png').write_bytes(b'asset-test-bytes')
            self.assertEqual(o.cli_pkg(['build',str(root)]),0)
            package=root/'embedded-demo.orbit'
            with zipfile.ZipFile(package) as z:
                names=z.namelist()
                self.assertIn('assets/sprites/player.png',names)
                self.assertIn('nano/runtime/compact_vm.py',names)
                self.assertIn('nano/libraries/orbit.console.lux',names)
                meta=json.loads(z.read('nano/metadata/nano.json'))
                self.assertTrue(meta['embedded'])
                self.assertEqual(meta['bytecode_format'],o.FORMAT)
                self.assertTrue(json.loads(z.read('orbit.json'))['embedded_nano'])
            self.assertEqual(o.cli_pkg(['run',str(package)]),0)
            self.assertEqual(o.cli_orbit(['run',str(package)]),0)
            extracted=Path(d)/'extracted'; extracted.mkdir()
            with zipfile.ZipFile(package) as z: z.extractall(extracted)
            import subprocess
            result=subprocess.run([sys.executable,str(extracted/'nano'/'run_embedded.py')],capture_output=True,text=True,timeout=20)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('EMBEDDED NANO OK',result.stdout)

    def test_loadnano_is_not_embedded_without_directive(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'project'; (root/'src').mkdir(parents=True)
            (root/'orbit.json').write_text(json.dumps({'name':'plain-app','version':'1.0.0','entry':'src/main.orb'}))
            (root/'src'/'main.orb').write_text('signal("plain")')
            self.assertEqual(o.cli_pkg(['build',str(root)]),0)
            with zipfile.ZipFile(root/'plain-app.orbit') as z:
                self.assertNotIn('nano/metadata/nano.json',z.namelist())
                self.assertIn('assets/',z.namelist())

    def test_package_embeds_custom_lib_and_nano_selects_builtins(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'project'; (root/'src').mkdir(parents=True); (root/'lib').mkdir()
            (root/'orbit.json').write_text(json.dumps({'name':'nano-test','version':'1.0.0','entry':'src/main.orb'}))
            (root/'lib'/'custom.lux').write_text('LUX-LIBRARY 01\nNAME nano.custom\nVERSION 1.0.0\nSTATUS IMPLEMENTED\nDESCRIPTION test\nNAMESPACE custom\nSOURCE custom.orb\nMODULE helpers\nEXPORT twice\n')
            (root/'lib'/'custom.orb').write_text('fn twice(x) { return x * 2 }\n')
            (root/'src'/'main.orb').write_text('lux.loadLib(orbit.math.lux)\nlux.loadLib("lib/custom.lux")\nsignal(custom.twice(math.sqrt(81)))')
            self.assertEqual(o.cli_pkg(['build',str(root)]),0)
            package=root/'nano-test.orbit'
            with zipfile.ZipFile(package) as z:
                manifest=json.loads(z.read('orbit.json'))
                self.assertIn('orbit.math',manifest['runtime_dependencies']['built_in'])
                self.assertIn('lib/custom.lux',manifest['runtime_dependencies']['custom'])
                self.assertIn('lib/custom.orb',z.namelist())
                self.assertIn('lib/custom.beam',z.namelist())
            nano=Path(d)/'nano.zip'
            self.assertEqual(o.cli_nano(['build',str(package),'-o',str(nano)]),0)
            extract=Path(d)/'nano-extract'; extract.mkdir()
            with zipfile.ZipFile(nano) as z: z.extractall(extract)
            with zipfile.ZipFile(nano) as z:
                names=z.namelist()
                self.assertIn('OrbitNano/runtime/stdlib/mathlib.py',names)
                self.assertIn('OrbitNano/runtime/compact_vm.py',names)
                self.assertIn('OrbitNano/libraries/orbit.math.lux',names)
                self.assertNotIn('OrbitNano/runtime/stdlib/network.py',names)
                self.assertNotIn('OrbitNano/orbit_tool.py',names)
                self.assertNotIn('OrbitNano/compiler/parser.py',names)
                self.assertIn('OrbitNano/app/nano-test.orbit',names)
                # Custom code remains inside the .orbit app; Nano does not copy it to shared lib folders.
                with zipfile.ZipFile(extract/'OrbitNano'/'app'/'nano-test.orbit') as app:
                    self.assertIn('lib/custom.lux',app.namelist())
                    self.assertIn('lib/custom.orb',app.namelist())
                    self.assertIn('lib/custom.beam',app.namelist())
            import subprocess
            result=subprocess.run([sys.executable,str(extract/'OrbitNano'/'run.py')],capture_output=True,text=True,timeout=20)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('18.0',result.stdout)
    def test_nano_graphics3d_includes_graphics_dependency(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'project'; (root/'src').mkdir(parents=True)
            (root/'orbit.json').write_text(json.dumps({'name':'nano-3d','version':'1.0.0','entry':'src/main.orb'}))
            (root/'src'/'main.orb').write_text('lux.loadLib(orbit.graphics3d.lux)\nvar mesh=graphics3d.cube(1)\nsignal(len(mesh["vertices"]))')
            self.assertEqual(o.cli_pkg(['build',str(root)]),0)
            package=root/'nano-3d.orbit'; nano=Path(d)/'nano-3d.zip'
            self.assertEqual(o.cli_nano(['build',str(package),'-o',str(nano)]),0)
            with zipfile.ZipFile(nano) as z:
                self.assertIn('OrbitNano/runtime/stdlib/graphics3d.py',z.namelist())
                self.assertIn('OrbitNano/runtime/stdlib/graphics.py',z.namelist())
    def test_nano_runs_a_flux_scene_with_selected_engine_modules(self):
        with tempfile.TemporaryDirectory() as d:
            root=Path(d)/'project'; (root/'src').mkdir(parents=True)
            (root/'orbit.json').write_text(json.dumps({'name':'nano-flux','version':'1.0.0','entry':'src/main.orb'}))
            source='lux.loadLib(orbit.fluxengine.lux)\nlux.loadLib(orbit.graphics.lux)\nvar w=flux.scene("test")\nflux.entity(w,"player",2,2,10,10,"#ffffff")\nvar c=graphics.canvas(16,16)\nflux.render(w,c)\nsignal("NANO FLUX OK")'
            (root/'src'/'main.orb').write_text(source)
            self.assertEqual(o.cli_pkg(['build',str(root)]),0)
            package=root/'nano-flux.orbit'; nano=Path(d)/'nano-flux.zip'
            self.assertEqual(o.cli_nano(['build',str(package),'-o',str(nano)]),0)
            extract=Path(d)/'run'; extract.mkdir()
            with zipfile.ZipFile(nano) as z: z.extractall(extract)
            import subprocess
            result=subprocess.run([sys.executable,str(extract/'OrbitNano'/'run.py')],capture_output=True,text=True,timeout=20)
            self.assertEqual(result.returncode,0,result.stderr)
            self.assertIn('NANO FLUX OK',result.stdout)
    def test_game_template_is_interactive(self):
        source=(ROOT/'templates/game-prototype/src/main.orb').read_text()
        program=o.compile_source(source)
        calls=[ins.get('arg',{}).get('name') for ins in program['code'] if ins.get('op')=='CALL']
        self.assertIn('flux.run',calls)
        self.assertNotIn('graphics.save_png',calls)
    def test_rejects_traversal_package(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/'bad.orbit'
            with zipfile.ZipFile(path,'w') as z:
                z.writestr('../escape.txt','bad'); z.writestr('orbit.json','{}'); z.writestr('main.beam','{}')
            self.assertNotEqual(o.cli_pkg(['inspect',str(path)]),0)

if __name__=='__main__': unittest.main(verbosity=2)
