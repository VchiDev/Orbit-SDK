from runtime.stdlib.window import create, label, run, close, set_title, set_size
__all__=["create","label","run","close","set_title","set_size"]
