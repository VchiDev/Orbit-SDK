from runtime.stdlib.input import key_down, mouse_position, mouse_down, bind_tk
__all__=["key_down","mouse_position","mouse_down","bind_tk"]
